package wg.app.store;

import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
public class NotifyService extends Service {
private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
private String FireMessage = "";
private String FireTitle = "";
private int num = 0;
private DatabaseReference Database = _firebase.getReference("Notification");
private FirebaseAuth auth;
private ChildEventListener _Database_child_listener;

public IBinder onBind(Intent arg0) {
return null;}


public void onCreate() {

_CreateChannelUser();

com.google.firebase.FirebaseApp.initializeApp(this);
_Database_child_listener = new ChildEventListener() {
	
@Override
public void onChildAdded(DataSnapshot _param1, String _param2) {
GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
final String _childKey = _param1.getKey();
final HashMap<String, Object> _childValue = _param1.getValue(_ind);

if (_childValue.get("to").toString().contains("all")) {
	num++;
FireMessage = _childValue.get("message").toString();
FireTitle = _childValue.get("title").toString();
Intent intent = new Intent(NotifyService.this, MainActivity.class);
intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
PendingIntent pendingIntent = PendingIntent.getActivity(NotifyService.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(NotifyService.this, "id 1")
.setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS)
.setSmallIcon(R.drawable.app_icon)
.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
.setContentTitle(FireTitle)
.setContentText(FireMessage)
.setContentIntent(pendingIntent)
.setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
.setAutoCancel(true);
androidx.core.app.NotificationManagerCompat notificationManager = androidx.core.app.NotificationManagerCompat.from(NotifyService.this);
notificationManager.notify(num, builder.build());
}
else {

if (_childValue.get("to").toString().contains(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
	
if (_childValue.get("read").toString().equals("0")) 
{
num++;
FireMessage = _childValue.get("message").toString();
FireTitle = _childValue.get("title").toString();
Intent intent = new Intent(NotifyService.this, MainActivity.class);
intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
PendingIntent pendingIntent = PendingIntent.getActivity(NotifyService.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(NotifyService.this, "id 1")
.setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS)
.setSmallIcon(R.drawable.app_icon)
.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
.setContentTitle(FireTitle)
.setContentText(FireMessage)
.setContentIntent(pendingIntent)
.setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
.setAutoCancel(true);
androidx.core.app.NotificationManagerCompat notificationManager = androidx.core.app.NotificationManagerCompat.from(NotifyService.this);
notificationManager.notify(num, builder.build());
}
}
}
}


@Override
public void onChildChanged(DataSnapshot _param1, String _param2) {
GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
final String _childKey = _param1.getKey();
final HashMap<String, Object> _childValue = _param1.getValue(_ind);
}


@Override
public void onChildMoved(DataSnapshot _param1, String _param2) {
}


@Override
public void onChildRemoved(DataSnapshot _param1) {
GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
final String _childKey = _param1.getKey();
final HashMap<String, Object> _childValue = _param1.getValue(_ind);
}


@Override
public void onCancelled(DatabaseError _param1) {
final int _errorCode = _param1.getCode();
final String _errorMessage = _param1.getMessage();
}
};
Database.addChildEventListener(_Database_child_listener);
}

private void _CreateChannelUser () {
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
CharSequence name = "All Notifications";
String description = "Don't Disable This Notifications";
int importance = NotificationManager.IMPORTANCE_DEFAULT;
NotificationChannel channel = new NotificationChannel("id 1", name, importance);
channel.setDescription(description);
NotificationManager notificationManager = getSystemService(NotificationManager.class);
notificationManager.createNotificationChannel(channel);
}
}

}