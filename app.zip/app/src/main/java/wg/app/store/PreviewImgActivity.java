package wg.app.store;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.bumptech.glide.Glide;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import com.jsibbold.zoomage.ZoomageView;

public class PreviewImgActivity extends AppCompatActivity {
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private ViewPager viewpager1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.preview_img);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		viewpager1 = findViewById(R.id.viewpager1);
	}
	
	private void initializeLogic() {
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("s1", getIntent().getStringExtra("s1"));
			listmap.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("s2", getIntent().getStringExtra("s2"));
			listmap.add(_item);
		}
		
		if (getIntent().hasExtra("s3")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s3", getIntent().getStringExtra("s3"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s4")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s4", getIntent().getStringExtra("s4"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s5")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s5", getIntent().getStringExtra("s5"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s6")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s6", getIntent().getStringExtra("s6"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s7")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s7", getIntent().getStringExtra("s7"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s8")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s8", getIntent().getStringExtra("s8"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s9")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s9", getIntent().getStringExtra("s9"));
				listmap.add(_item);
			}
			
		}
		if (getIntent().hasExtra("s10")) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("s10", getIntent().getStringExtra("s10"));
				listmap.add(_item);
			}
			
		}
		viewpager1.setAdapter(new Viewpager1Adapter(listmap));
		viewpager1.setCurrentItem((int)0);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS); getWindow().setStatusBarColor(Color.TRANSPARENT);
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
	}
	
	public class Viewpager1Adapter extends PagerAdapter {
		
		Context _context;
		ArrayList<HashMap<String, Object>> _data;
		
		public Viewpager1Adapter(Context _ctx, ArrayList<HashMap<String, Object>> _arr) {
			_context = _ctx;
			_data = _arr;
		}
		
		public Viewpager1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_context = getApplicationContext();
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public boolean isViewFromObject(View _view, Object _object) {
			return _view == _object;
		}
		
		@Override
		public void destroyItem(ViewGroup _container, int _position, Object _object) {
			_container.removeView((View) _object);
		}
		
		@Override
		public int getItemPosition(Object _object) {
			return super.getItemPosition(_object);
		}
		
		@Override
		public CharSequence getPageTitle(int pos) {
			// Use the Activity Event (onTabLayoutNewTabAdded) in order to use this method
			return "page " + String.valueOf(pos);
		}
		
		@Override
		public Object instantiateItem(ViewGroup _container,  final int _position) {
			View _view = LayoutInflater.from(_context).inflate(R.layout.img_preview, _container, false);
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final com.jsibbold.zoomage.ZoomageView imageview1 = _view.findViewById(R.id.imageview1);
			
			if (_position == 0) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s1").toString())).into(imageview1);
			}
			if (_position == 1) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s2").toString())).into(imageview1);
			}
			if (_position == 2) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s3").toString())).into(imageview1);
			}
			if (_position == 3) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s4").toString())).into(imageview1);
			}
			if (_position == 4) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s5").toString())).into(imageview1);
			}
			if (_position == 5) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s6").toString())).into(imageview1);
			}
			if (_position == 6) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s7").toString())).into(imageview1);
			}
			if (_position == 7) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s8").toString())).into(imageview1);
			}
			if (_position == 8) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s9").toString())).into(imageview1);
			}
			if (_position == 9) {
				Glide.with(getApplicationContext()).load(Uri.parse(listmap.get((int)_position).get("s10").toString())).into(imageview1);
			}
			
			_container.addView(_view);
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}