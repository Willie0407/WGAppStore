package wg.app.store;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.provider.Settings.Secure;

public class AuthActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String emailAddress = "";
	private String password = "";
	private String total_users = "";
	private HashMap<String, Object> server_map = new HashMap<>();
	private HashMap<String, Object> user_map = new HashMap<>();
	private HashMap<String, Object> phones_map = new HashMap<>();
	private String language = "";
	
	private ArrayList<Double> nl = new ArrayList<>();
	private ArrayList<String> ls = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout linear3;
	private ImageView image;
	private TextView title;
	private TextView subtitle;
	private LinearLayout login_btn;
	private LinearLayout linear4;
	private ImageView google_image;
	private TextView btn_title;
	private LinearLayout linear5;
	private TextView terms_btn;
	private TextView privacy_btn;
	
	private Intent i = new Intent();
	private SharedPreferences settings;
	private Calendar cal = Calendar.getInstance();
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private DatabaseReference server = _firebase.getReference("server");
	private ChildEventListener _server_child_listener;
	private DatabaseReference phones = _firebase.getReference("phones");
	private ChildEventListener _phones_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.auth);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		linear3 = findViewById(R.id.linear3);
		image = findViewById(R.id.image);
		title = findViewById(R.id.title);
		subtitle = findViewById(R.id.subtitle);
		login_btn = findViewById(R.id.login_btn);
		linear4 = findViewById(R.id.linear4);
		google_image = findViewById(R.id.google_image);
		btn_title = findViewById(R.id.btn_title);
		linear5 = findViewById(R.id.linear5);
		terms_btn = findViewById(R.id.terms_btn);
		privacy_btn = findViewById(R.id.privacy_btn);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		auth = FirebaseAuth.getInstance();
		net = new RequestNetwork(this);
		
		login_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = com.google.android.gms.common.AccountPicker.newChooseAccountIntent(null, null, new String[]{"com.google"}, false, null, null, null, null); startActivityForResult(intent, 94);
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_server_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("total_users")) {
					total_users = _childValue.get("total_users").toString();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("total_users")) {
					total_users = _childValue.get("total_users").toString();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("total_users")) {
					total_users = _childValue.get("total_users").toString();
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				FancyToast.makeText(AuthActivity.this, _errorMessage, FancyToast.LENGTH_LONG, FancyToast.ERROR, false).show();
			}
		};
		server.addChildEventListener(_server_child_listener);
		
		_phones_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		phones.addChildEventListener(_phones_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				i.setClass(getApplicationContext(), OfflineActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					cal = Calendar.getInstance();
					user_map = new HashMap<>();
					user_map.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
					user_map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					user_map.put("verified", "");
					user_map.put("banned", "");
					user_map.put("developer", "");
					user_map.put("balance", "0");
					user_map.put("device", Build.MODEL);
					user_map.put("device_id", //import android.provider.Settings.Secure;
					Secure.getString(AuthActivity.this.getContentResolver(), Secure.ANDROID_ID));
					user_map.put("joined_date", new SimpleDateFormat("hh:mm EEE, d MMM").format(cal.getTime()));
					user_map.put("language", settings.getString("language", ""));
					users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(user_map);
					user_map.clear();
					phones_map = new HashMap<>();
					phones_map.put("build_type", Build.TYPE);
					phones_map.put("build_tags", Build.TAGS);
					phones_map.put("build_user", Build.USER);
					phones_map.put("build_unknown", Build.UNKNOWN);
					phones_map.put("build_id", Build.ID);
					phones_map.put("build_product", Build.PRODUCT);
					phones_map.put("build_display", Build.DISPLAY);
					phones_map.put("build_fingerprint", Build.FINGERPRINT);
					phones_map.put("build_cpu_abi", Build.CPU_ABI);
					phones_map.put("build_host", Build.HOST);
					phones_map.put("build_radio", Build.RADIO);
					phones_map.put("build_hardware", Build.HARDWARE);
					phones_map.put("build_serial", Build.SERIAL);
					phones_map.put("build_bootloader", Build.BOOTLOADER);
					phones_map.put("build_board", Build.BOARD);
					phones_map.put("build_version_security_patch", Build.VERSION.SECURITY_PATCH);
					phones_map.put("build_brand", Build.BRAND);
					phones_map.put("build_version_sdk", Build.VERSION.SDK);
					phones_map.put("build_manufacturer", Build.MANUFACTURER);
					phones_map.put("build_model", Build.MODEL);
					phones_map.put("build_version_release", Build.VERSION.RELEASE);
					phones_map.put("android_id", //import android.provider.Settings.Secure;
					Secure.getString(AuthActivity.this.getContentResolver(), Secure.ANDROID_ID));
					phones_map.put("last_live_time", new SimpleDateFormat("hh:mm EEE, d MMM").format(cal.getTime()));
					phones_map.put("approved", "true");
					phones.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(phones_map);
					phones_map.clear();
					server_map = new HashMap<>();
					server_map.put("", String.valueOf((long)(Double.parseDouble(total_users) + 0)));
					server.push().updateChildren(server_map);
					server_map.clear();
					i.setClass(getApplicationContext(), SetProfileActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					finish();
				}
				else {
					FancyToast.makeText(AuthActivity.this, _errorMessage, FancyToast.LENGTH_LONG, FancyToast.ERROR, false).show();
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					cal = Calendar.getInstance();
					user_map = new HashMap<>();
					user_map.put("last_login", new SimpleDateFormat("hh:mm EEE, d MMM").format(cal.getTime()));
					user_map.put("device", Build.MODEL);
					user_map.put("device_id", //import android.provider.Settings.Secure;
					Secure.getString(AuthActivity.this.getContentResolver(), Secure.ANDROID_ID));
					users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(user_map);
					user_map.clear();
					i.setClass(getApplicationContext(), SecurityCheckActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					finish();
				}
				else {
					if (_errorMessage.equals("There is no user record corresponding to this identifier. The user may have been deleted.")) {
						auth.createUserWithEmailAndPassword(emailAddress, password).addOnCompleteListener(AuthActivity.this, _auth_create_user_listener);
					}
					else {
						FancyToast.makeText(AuthActivity.this, _errorMessage, FancyToast.LENGTH_LONG, FancyToast.ERROR, false).show();
					}
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_theme();
		_check();
		_translate(title);
		_translate(subtitle);
		_translate(btn_title);
		_translate(terms_btn);
		_translate(privacy_btn);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
			}; break; case 94: try { _onAccountPicked(_data.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME).toString(), _data.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_TYPE).toString()); } catch (Exception e) { }; if (false) {
			}
			else {
				FancyToast.makeText(AuthActivity.this, "Failed To Connect Your Account...", FancyToast.LENGTH_LONG, FancyToast.ERROR, false).show();
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		
	}
	
	public void _theme() {
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		login_btn.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(login_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(login_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(login_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(login_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =AuthActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF212121);
			}
			main.setBackgroundColor(0xFF212121);
			int[] colorsCRNJS = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNJS = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNJS);
			CRNJS.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
			CRNJS.setStroke((int) 2, Color.parseColor("#FFFFFF"));
			login_btn.setElevation((float) 5);
			login_btn.setBackground(CRNJS);
			btn_title.setTextColor(0xFFFFFFFF);
				
		} else {
				
				//Dark mode off
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =AuthActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFFFFFF);
			}
			main.setBackgroundColor(0xFFFFFFFF);
			int[] colorsCRNPA = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNPA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNPA);
			CRNPA.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
			CRNPA.setStroke((int) 2, Color.parseColor("#212121"));
			login_btn.setElevation((float) 5);
			login_btn.setBackground(CRNPA);
			btn_title.setTextColor(0xFF212121);
				
		};
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	
	public void _check() {
		net.startRequestNetwork(RequestNetworkController.GET, "https://google.com/", "A", _net_request_listener);
	}
	
	
	public void _onAccountPicked(final String _email, final String _password) {
		emailAddress = _email;
		password = _password;
		auth.signInWithEmailAndPassword(emailAddress, password).addOnCompleteListener(AuthActivity.this, _auth_sign_in_listener);
		FancyToast.makeText(AuthActivity.this, "Connecting Your Account...", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
	}
	
	
	public void _roundcorner(final double _a, final double _b, final double _c, final double _d, final String _BGcolor, final View _view) {
		Double tlr = _a;
		Double trr = _b;
		Double blr = _c;
		Double brr = _d;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_BGcolor));
		_view.setBackground(s);
	}
	
	
	public void _translate(final TextView _text) {
		language = Locale.getDefault().getDisplayLanguage();
		if (language.equals("Afrikaans")) {
			TranslateAPI translateAPI = new TranslateAPI(
							Language.ENGLISH,
							Language.AFRIKAANS,
							_text.getText().toString());
				translateAPI.setTranslateListener(new TranslateAPI.TranslateListener() {
										@Override
										public void onSuccess(String translatedText) {
					    //Success
													_text.setText(translatedText);
										}
						
										@Override
										public void onFailure(String ErrorText) {
							//Falied
										}
							});
		}
		else {
			if (language.equals("Spanish")) {
				TranslateAPI translateAPI = new TranslateAPI(
								Language.ENGLISH,
								Language.SPANISH,
								_text.getText().toString());
					translateAPI.setTranslateListener(new TranslateAPI.TranslateListener() {
											@Override
											public void onSuccess(String translatedText) {
						    //Success
														_text.setText(translatedText);
											}
							
											@Override
											public void onFailure(String ErrorText) {
								//Falied
											}
								});
			}
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}