package wg.app.store;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class GameViewActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private boolean is_busy_downloading = false;
	private double number = 0;
	private HashMap<String, Object> game_id = new HashMap<>();
	private HashMap<String, Object> games_map = new HashMap<>();
	private boolean is_game_installed = false;
	private double total_likes = 0;
	private double total_downloads = 0;
	
	private LinearLayout tab;
	private ScrollView vscroll2;
	private ImageView back_btn;
	private LinearLayout linear6;
	private ImageView menu_btn;
	private TextView app_name1;
	private LinearLayout main;
	private LinearLayout linear7;
	private HorizontalScrollView hscroll1;
	private HorizontalScrollView hscroll2;
	private LinearLayout progress_back;
	private LinearLayout btns_back;
	private LinearLayout whats_new_back1;
	private LinearLayout whats_new_back2;
	private HorizontalScrollView hscroll3;
	private LinearLayout linear52;
	private LinearLayout linear1;
	private LinearLayout rate_back;
	private RatingBar ratingbar1;
	private LinearLayout linear57;
	private ListView comments_listview;
	private AdView adview1;
	private ImageView app_icon;
	private LinearLayout linear8;
	private TextView app_name2;
	private TextView publisher_name;
	private TextView app_size;
	private TextView app_price;
	private LinearLayout linear9;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private ImageView like_icon;
	private TextView likes;
	private ImageView download_icon;
	private TextView downloads;
	private ImageView ratings_icon;
	private TextView ratings;
	private ImageView comments_icon;
	private TextView comments;
	private ImageView votes_icon;
	private TextView votes;
	private ImageView age_icon;
	private TextView age_rating;
	private LinearLayout linear22;
	private LinearLayout editor_tag;
	private LinearLayout users_tag;
	private LinearLayout verified_tag;
	private LinearLayout trending_tag;
	private LinearLayout popular_tag;
	private LinearLayout beta_tag;
	private LinearLayout premium_tag;
	private ImageView imageview10;
	private TextView textview12;
	private ImageView imageview11;
	private TextView textview13;
	private ImageView imageview12;
	private TextView textview14;
	private ImageView imageview17;
	private TextView textview19;
	private ImageView imageview13;
	private TextView textview15;
	private ImageView imageview14;
	private TextView textview16;
	private ImageView imageview18;
	private TextView textview20;
	private TextView download_progress;
	private ProgressBar progressbar1;
	private Button uninstall_btn;
	private Button install_btn;
	private LinearLayout linear39;
	private ImageView imageview19;
	private TextView textview25;
	private TextView whats_new;
	private LinearLayout linear40;
	private LinearLayout screenshot1_back;
	private LinearLayout screenshot2_back;
	private LinearLayout screenshot3_back;
	private LinearLayout screenshot4_back;
	private LinearLayout screenshot5_back;
	private LinearLayout screenshot6_back;
	private LinearLayout screenshot7_back;
	private LinearLayout screenshot8_back;
	private LinearLayout screenshot9_back;
	private LinearLayout screenshot10_back;
	private ImageView screenshot1;
	private ImageView screenshot2;
	private ImageView screenshot3;
	private ImageView screenshot4;
	private ImageView screenshot5;
	private ImageView screenshot6;
	private ImageView screenshot7;
	private ImageView screenshot8;
	private ImageView screenshot9;
	private ImageView screenshot10;
	private LinearLayout linear53;
	private ImageView imageview30;
	private TextView textview26;
	private TextView about;
	private LinearLayout linear56;
	private TextView textview28;
	private LinearLayout linear58;
	private ImageView imageview32;
	private TextView textview29;
	
	private Intent intent = new Intent();
	private TimerTask timer;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference favorites_games = _firebase.getReference("favorites_games");
	private ChildEventListener _favorites_games_child_listener;
	private DatabaseReference game_comments = _firebase.getReference("game_comments");
	private ChildEventListener _game_comments_child_listener;
	private DatabaseReference purchases = _firebase.getReference("purchases");
	private ChildEventListener _purchases_child_listener;
	private StorageReference downloader = _firebase_storage.getReference("downloader");
	private OnCompleteListener<Uri> _downloader_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _downloader_download_success_listener;
	private OnSuccessListener _downloader_delete_success_listener;
	private OnProgressListener _downloader_upload_progress_listener;
	private OnProgressListener _downloader_download_progress_listener;
	private OnFailureListener _downloader_failure_listener;
	
	private DatabaseReference game_rated = _firebase.getReference("game_rated");
	private ChildEventListener _game_rated_child_listener;
	private DatabaseReference games = _firebase.getReference("games");
	private ChildEventListener _games_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.game_view);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		tab = findViewById(R.id.tab);
		vscroll2 = findViewById(R.id.vscroll2);
		back_btn = findViewById(R.id.back_btn);
		linear6 = findViewById(R.id.linear6);
		menu_btn = findViewById(R.id.menu_btn);
		app_name1 = findViewById(R.id.app_name1);
		main = findViewById(R.id.main);
		linear7 = findViewById(R.id.linear7);
		hscroll1 = findViewById(R.id.hscroll1);
		hscroll2 = findViewById(R.id.hscroll2);
		progress_back = findViewById(R.id.progress_back);
		btns_back = findViewById(R.id.btns_back);
		whats_new_back1 = findViewById(R.id.whats_new_back1);
		whats_new_back2 = findViewById(R.id.whats_new_back2);
		hscroll3 = findViewById(R.id.hscroll3);
		linear52 = findViewById(R.id.linear52);
		linear1 = findViewById(R.id.linear1);
		rate_back = findViewById(R.id.rate_back);
		ratingbar1 = findViewById(R.id.ratingbar1);
		linear57 = findViewById(R.id.linear57);
		comments_listview = findViewById(R.id.comments_listview);
		adview1 = findViewById(R.id.adview1);
		app_icon = findViewById(R.id.app_icon);
		linear8 = findViewById(R.id.linear8);
		app_name2 = findViewById(R.id.app_name2);
		publisher_name = findViewById(R.id.publisher_name);
		app_size = findViewById(R.id.app_size);
		app_price = findViewById(R.id.app_price);
		linear9 = findViewById(R.id.linear9);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		like_icon = findViewById(R.id.like_icon);
		likes = findViewById(R.id.likes);
		download_icon = findViewById(R.id.download_icon);
		downloads = findViewById(R.id.downloads);
		ratings_icon = findViewById(R.id.ratings_icon);
		ratings = findViewById(R.id.ratings);
		comments_icon = findViewById(R.id.comments_icon);
		comments = findViewById(R.id.comments);
		votes_icon = findViewById(R.id.votes_icon);
		votes = findViewById(R.id.votes);
		age_icon = findViewById(R.id.age_icon);
		age_rating = findViewById(R.id.age_rating);
		linear22 = findViewById(R.id.linear22);
		editor_tag = findViewById(R.id.editor_tag);
		users_tag = findViewById(R.id.users_tag);
		verified_tag = findViewById(R.id.verified_tag);
		trending_tag = findViewById(R.id.trending_tag);
		popular_tag = findViewById(R.id.popular_tag);
		beta_tag = findViewById(R.id.beta_tag);
		premium_tag = findViewById(R.id.premium_tag);
		imageview10 = findViewById(R.id.imageview10);
		textview12 = findViewById(R.id.textview12);
		imageview11 = findViewById(R.id.imageview11);
		textview13 = findViewById(R.id.textview13);
		imageview12 = findViewById(R.id.imageview12);
		textview14 = findViewById(R.id.textview14);
		imageview17 = findViewById(R.id.imageview17);
		textview19 = findViewById(R.id.textview19);
		imageview13 = findViewById(R.id.imageview13);
		textview15 = findViewById(R.id.textview15);
		imageview14 = findViewById(R.id.imageview14);
		textview16 = findViewById(R.id.textview16);
		imageview18 = findViewById(R.id.imageview18);
		textview20 = findViewById(R.id.textview20);
		download_progress = findViewById(R.id.download_progress);
		progressbar1 = findViewById(R.id.progressbar1);
		uninstall_btn = findViewById(R.id.uninstall_btn);
		install_btn = findViewById(R.id.install_btn);
		linear39 = findViewById(R.id.linear39);
		imageview19 = findViewById(R.id.imageview19);
		textview25 = findViewById(R.id.textview25);
		whats_new = findViewById(R.id.whats_new);
		linear40 = findViewById(R.id.linear40);
		screenshot1_back = findViewById(R.id.screenshot1_back);
		screenshot2_back = findViewById(R.id.screenshot2_back);
		screenshot3_back = findViewById(R.id.screenshot3_back);
		screenshot4_back = findViewById(R.id.screenshot4_back);
		screenshot5_back = findViewById(R.id.screenshot5_back);
		screenshot6_back = findViewById(R.id.screenshot6_back);
		screenshot7_back = findViewById(R.id.screenshot7_back);
		screenshot8_back = findViewById(R.id.screenshot8_back);
		screenshot9_back = findViewById(R.id.screenshot9_back);
		screenshot10_back = findViewById(R.id.screenshot10_back);
		screenshot1 = findViewById(R.id.screenshot1);
		screenshot2 = findViewById(R.id.screenshot2);
		screenshot3 = findViewById(R.id.screenshot3);
		screenshot4 = findViewById(R.id.screenshot4);
		screenshot5 = findViewById(R.id.screenshot5);
		screenshot6 = findViewById(R.id.screenshot6);
		screenshot7 = findViewById(R.id.screenshot7);
		screenshot8 = findViewById(R.id.screenshot8);
		screenshot9 = findViewById(R.id.screenshot9);
		screenshot10 = findViewById(R.id.screenshot10);
		linear53 = findViewById(R.id.linear53);
		imageview30 = findViewById(R.id.imageview30);
		textview26 = findViewById(R.id.textview26);
		about = findViewById(R.id.about);
		linear56 = findViewById(R.id.linear56);
		textview28 = findViewById(R.id.textview28);
		linear58 = findViewById(R.id.linear58);
		imageview32 = findViewById(R.id.imageview32);
		textview29 = findViewById(R.id.textview29);
		auth = FirebaseAuth.getInstance();
		
		back_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_DoubleClickToExit();
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("balance")) {
						balance = Double.parseDouble(_childValue.get("balance").toString());
					}
				}
				if (_childKey.equals(publisher_uid)) {
					if (_childValue.containsKey("balance")) {
						publisher_balance = Double.parseDouble(_childValue.get("balance").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("balance")) {
						balance = Double.parseDouble(_childValue.get("balance").toString());
					}
				}
				if (_childKey.equals(publisher_uid)) {
					if (_childValue.containsKey("balance")) {
						publisher_balance = Double.parseDouble(_childValue.get("balance").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("balance")) {
						balance = Double.parseDouble(_childValue.get("balance").toString());
					}
				}
				if (_childKey.equals(publisher_uid)) {
					if (_childValue.containsKey("balance")) {
						publisher_balance = Double.parseDouble(_childValue.get("balance").toString());
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_favorites_games_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(app_id)) {
					if (_childValue.containsKey("uid")) {
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("liked")) {
								if (_childValue.get("liked").toString().equals("true")) {
									like_icon.setImageResource(R.drawable.ic_favorite_white);
									is_liked = true;
								}
								else {
									like_icon.setImageResource(R.drawable.ic_favorite_outline_white);
									is_liked = false;
								}
							}
						}
						else {
							like_icon.setImageResource(R.drawable.ic_favorite_outline_white);
							is_liked = false;
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(app_id)) {
					if (_childValue.containsKey("uid")) {
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("liked")) {
								if (_childValue.get("liked").toString().equals("true")) {
									like_icon.setImageResource(R.drawable.ic_favorite_white);
									is_liked = true;
								}
								else {
									like_icon.setImageResource(R.drawable.ic_favorite_outline_white);
									is_liked = false;
								}
							}
						}
						else {
							like_icon.setImageResource(R.drawable.ic_favorite_outline_white);
							is_liked = false;
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(app_id)) {
					if (_childValue.containsKey("uid")) {
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("liked")) {
								if (_childValue.get("liked").toString().equals("true")) {
									like_icon.setImageResource(R.drawable.ic_favorite_white);
									is_liked = true;
								}
								else {
									like_icon.setImageResource(R.drawable.ic_favorite_outline_white);
									is_liked = false;
								}
							}
						}
						else {
							like_icon.setImageResource(R.drawable.ic_favorite_outline_white);
							is_liked = false;
						}
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		favorites_games.addChildEventListener(_favorites_games_child_listener);
		
		_game_comments_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("app_id")) {
					if (_childValue.get("app_id").toString().equals(app_id)) {
						app_comments.addListenerForSingleValueEvent(new ValueEventListener() {
							@Override
							public void onDataChange(DataSnapshot _dataSnapshot) {
								comments_listmap = new ArrayList<>();
								try {
									GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
									for (DataSnapshot _data : _dataSnapshot.getChildren()) {
										HashMap<String, Object> _map = _data.getValue(_ind);
										comments_listmap.add(_map);
									}
								}
								catch (Exception _e) {
									_e.printStackTrace();
								}
								comments_listview.setAdapter(new Comments_listviewAdapter(comments_listmap));
								((BaseAdapter)comments_listview.getAdapter()).notifyDataSetChanged();
							}
							@Override
							public void onCancelled(DatabaseError _databaseError) {
							}
						});
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("app_id")) {
					if (_childValue.get("app_id").toString().equals(app_id)) {
						app_comments.addListenerForSingleValueEvent(new ValueEventListener() {
							@Override
							public void onDataChange(DataSnapshot _dataSnapshot) {
								comments_listmap = new ArrayList<>();
								try {
									GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
									for (DataSnapshot _data : _dataSnapshot.getChildren()) {
										HashMap<String, Object> _map = _data.getValue(_ind);
										comments_listmap.add(_map);
									}
								}
								catch (Exception _e) {
									_e.printStackTrace();
								}
								comments_listview.setAdapter(new Comments_listviewAdapter(comments_listmap));
								((BaseAdapter)comments_listview.getAdapter()).notifyDataSetChanged();
							}
							@Override
							public void onCancelled(DatabaseError _databaseError) {
							}
						});
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("app_id")) {
					if (_childValue.get("app_id").toString().equals(app_id)) {
						app_comments.addListenerForSingleValueEvent(new ValueEventListener() {
							@Override
							public void onDataChange(DataSnapshot _dataSnapshot) {
								comments_listmap = new ArrayList<>();
								try {
									GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
									for (DataSnapshot _data : _dataSnapshot.getChildren()) {
										HashMap<String, Object> _map = _data.getValue(_ind);
										comments_listmap.add(_map);
									}
								}
								catch (Exception _e) {
									_e.printStackTrace();
								}
								comments_listview.setAdapter(new Comments_listviewAdapter(comments_listmap));
								((BaseAdapter)comments_listview.getAdapter()).notifyDataSetChanged();
							}
							@Override
							public void onCancelled(DatabaseError _databaseError) {
							}
						});
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		game_comments.addChildEventListener(_game_comments_child_listener);
		
		_purchases_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		purchases.addChildEventListener(_purchases_child_listener);
		
		_downloader_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_downloader_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				_notification("Downloading: ".concat(app_name2.getText().toString()), "Progress: ".concat(String.valueOf((long)(_progressValue)).concat("%")), 1, true);
				download_progress.setText(String.valueOf((long)(_progressValue)).concat("%"));
				progressbar1.setProgress((int)_progressValue);
				progress_back.setVisibility(View.VISIBLE);
				btns_back.setVisibility(View.GONE);
				is_busy_downloading = true;
			}
		};
		
		_downloader_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_downloader_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				_notification(app_name2.getText().toString().concat(" Has Been Downloaded."), app_name2.getText().toString().concat(" Was Downloaded Successfully."), 1, false);
				progress_back.setVisibility(View.GONE);
				btns_back.setVisibility(View.VISIBLE);
				is_busy_downloading = false;
				apps_map = new HashMap<>();
				apps_map.put("downloads", String.valueOf((long)(total_downloads + 1)));
				apps.child(app_id).updateChildren(apps_map);
				apps_map.clear();
				_Install("/storage/emulated/0/WG App Store/Apps/".concat(app_package_name));
			}
		};
		
		_downloader_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_downloader_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				_notification("Failed To Download: ".concat(app_name2.getText().toString()), _message, 1, false);
				progress_back.setVisibility(View.GONE);
				btns_back.setVisibility(View.VISIBLE);
				is_busy_downloading = false;
			}
		};
		
		_game_rated_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(app_id)) {
					if (_childValue.containsKey("uid")) {
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("rated")) {
								if (_childValue.get("rated").toString().equals("true")) {
									rate_back.setVisibility(View.GONE);
									ratingbar1.setVisibility(View.GONE);
									is_rated = true;
								}
								else {
									rate_back.setVisibility(View.VISIBLE);
									ratingbar1.setVisibility(View.VISIBLE);
									is_rated = false;
								}
							}
						}
						else {
							rate_back.setVisibility(View.VISIBLE);
							ratingbar1.setVisibility(View.VISIBLE);
							is_rated = false;
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(app_id)) {
					if (_childValue.containsKey("uid")) {
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("rated")) {
								if (_childValue.get("rated").toString().equals("true")) {
									rate_back.setVisibility(View.GONE);
									ratingbar1.setVisibility(View.GONE);
									is_rated = true;
								}
								else {
									rate_back.setVisibility(View.VISIBLE);
									ratingbar1.setVisibility(View.VISIBLE);
									is_rated = false;
								}
							}
						}
						else {
							rate_back.setVisibility(View.VISIBLE);
							ratingbar1.setVisibility(View.VISIBLE);
							is_rated = false;
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(app_id)) {
					if (_childValue.containsKey("uid")) {
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("rated")) {
								if (_childValue.get("rated").toString().equals("true")) {
									rate_back.setVisibility(View.GONE);
									ratingbar1.setVisibility(View.GONE);
									is_rated = true;
								}
								else {
									rate_back.setVisibility(View.VISIBLE);
									ratingbar1.setVisibility(View.VISIBLE);
									is_rated = false;
								}
							}
						}
						else {
							rate_back.setVisibility(View.VISIBLE);
							ratingbar1.setVisibility(View.VISIBLE);
							is_rated = false;
						}
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		game_rated.addChildEventListener(_game_rated_child_listener);
		
		_games_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("app_id"))) {
					if (_childValue.containsKey("package_name")) {
						app_package_name = _childValue.get("package_name").toString();
						boolean isAppInstalled = appInstalledOrNot(_childValue.get("package_name").toString()); 
						
						if(isAppInstalled) {
							
								is_app_installed = true;
							uninstall_btn.setVisibility(View.VISIBLE);
							install_btn.setText("Open");
							
						} else {
							
							is_app_installed = false;
							uninstall_btn.setVisibility(View.GONE);
							
						}}
					
					private boolean appInstalledOrNot(String uri) { android.content.pm.PackageManager pm = getPackageManager(); try { pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES); return true; } catch (android.content.pm.PackageManager.NameNotFoundException e) { } return false;
					}
					if (_childValue.containsKey("icon")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("icon").toString())).into(app_icon);
					}
					if (_childValue.containsKey("name")) {
						app_name1.setText(_childValue.get("name").toString());
						app_name2.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("publisher_name")) {
						publisher_name.setText(_childValue.get("publisher_name").toString());
					}
					if (_childValue.containsKey("price")) {
						app_price.setText("$".concat(_childValue.get("price").toString().concat(".00")));
						price = Double.parseDouble(_childValue.get("price").toString());
						premium_tag.setVisibility(View.VISIBLE);
						is_premium_app = true;
					}
					else {
						premium_tag.setVisibility(View.GONE);
						is_premium_app = false;
					}
					if (_childValue.containsKey("size")) {
						app_size.setText(_childValue.get("size").toString());
					}
					if (_childValue.containsKey("likes")) {
						total_likes = Double.parseDouble(_childValue.get("likes").toString());
						likes.setText(_childValue.get("likes").toString());
					}
					else {
						total_likes = 0;
					}
					if (_childValue.containsKey("downloads")) {
						total_downloads = Double.parseDouble(_childValue.get("downloads").toString());
						downloads.setText(_childValue.get("downloads").toString());
					}
					else {
						total_downloads = 0;
					}
					if (_childValue.containsKey("ratings")) {
						total_ratings = Double.parseDouble(_childValue.get("ratings").toString());
						ratings.setText(_childValue.get("ratings").toString().concat("⭐"));
					}
					else {
						total_ratings = 0;
					}
					if (_childValue.containsKey("comments")) {
						total_comments = Double.parseDouble(_childValue.get("comments").toString());
						comments.setText(_childValue.get("comments").toString());
					}
					else {
						total_comments = 0;
					}
					if (_childValue.containsKey("votes")) {
						total_votes = Double.parseDouble(_childValue.get("votes").toString());
						votes.setText(_childValue.get("votes").toString());
					}
					else {
						total_votes = 0;
					}
					if (_childValue.containsKey("age_rating")) {
						age_rating.setText(_childValue.get("age_rating").toString().concat("+"));
					}
					if (_childValue.containsKey("whats_new")) {
						_setTextLink(whats_new, _childValue.get("whats_new").toString());
					}
					else {
						whats_new_back1.setVisibility(View.GONE);
						whats_new_back2.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("about")) {
						_setTextLink(about, _childValue.get("about").toString());
					}
					if (_childValue.containsKey("screenshot1")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot1").toString())).into(screenshot1);
						s1_link = _childValue.get("screenshot1").toString();
					}
					else {
						screenshot1_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot2")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot2").toString())).into(screenshot2);
						s2_link = _childValue.get("screenshot2").toString();
					}
					else {
						screenshot2_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot3")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot3").toString())).into(screenshot3);
						s3_link = _childValue.get("screenshot3").toString();
					}
					else {
						screenshot3_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot4")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot4").toString())).into(screenshot4);
						s4_link = _childValue.get("screenshot4").toString();
					}
					else {
						screenshot4_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot5")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot5").toString())).into(screenshot5);
						s5_link = _childValue.get("screenshot5").toString();
					}
					else {
						screenshot5_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot6")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot6").toString())).into(screenshot6);
						s6_link = _childValue.get("screenshot6").toString();
					}
					else {
						screenshot6_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot7")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot7").toString())).into(screenshot7);
						s7_link = _childValue.get("screenshot7").toString();
					}
					else {
						screenshot7_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot8")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot8").toString())).into(screenshot8);
						s8_link = _childValue.get("screenshot8").toString();
					}
					else {
						screenshot8_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot9")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot9").toString())).into(screenshot9);
						s9_link = _childValue.get("screenshot9").toString();
					}
					else {
						screenshot9_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot10")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot10").toString())).into(screenshot10);
						s10_link = _childValue.get("screenshot10").toString();
					}
					else {
						screenshot10_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("editor")) {
						if (_childValue.get("editor").toString().equals("true")) {
							editor_tag.setVisibility(View.VISIBLE);
						}
						else {
							editor_tag.setVisibility(View.GONE);
						}
					}
					if (_childValue.containsKey("votes")) {
						if (Double.parseDouble(_childValue.get("votes").toString()) > 150) {
							users_tag.setVisibility(View.VISIBLE);
						}
						else {
							users_tag.setVisibility(View.GONE);
						}
					}
					else {
						users_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							verified_tag.setVisibility(View.VISIBLE);
						}
						else {
							verified_tag.setVisibility(View.GONE);
						}
					}
					else {
						verified_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("likes") && _childValue.containsKey("downloads")) {
						if ((Double.parseDouble(_childValue.get("likes").toString()) > 250) && (Double.parseDouble(_childValue.get("downloads").toString()) > 500)) {
							trending_tag.setVisibility(View.VISIBLE);
						}
						else {
							trending_tag.setVisibility(View.GONE);
						}
					}
					else {
						trending_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("likes") && (_childValue.containsKey("downloads") && _childValue.containsKey("ratings"))) {
						if ((Double.parseDouble(_childValue.get("likes").toString()) > 100) && ((Double.parseDouble(_childValue.get("downloads").toString()) > 100) && (Double.parseDouble(_childValue.get("ratings").toString()) > 100))) {
							popular_tag.setVisibility(View.VISIBLE);
						}
						else {
							popular_tag.setVisibility(View.GONE);
						}
					}
					else {
						popular_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("beta")) {
						if (_childValue.get("beta").toString().equals("true")) {
							beta_tag.setVisibility(View.VISIBLE);
						}
						else {
							beta_tag.setVisibility(View.GONE);
						}
					}
					else {
						beta_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("publisher_uid")) {
						publisher_uid = _childValue.get("publisher_uid").toString();
					}
					if (_childValue.containsKey("app_link")) {
						app_link = _childValue.get("app_link").toString();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("app_id"))) {
					if (_childValue.containsKey("package_name")) {
						app_package_name = _childValue.get("package_name").toString();
						boolean isAppInstalled = appInstalledOrNot(_childValue.get("package_name").toString()); 
						
						if(isAppInstalled) {
							
								is_app_installed = true;
							uninstall_btn.setVisibility(View.VISIBLE);
							install_btn.setText("Open");
							
						} else {
							
							is_app_installed = false;
							uninstall_btn.setVisibility(View.GONE);
							
						}}
					
					private boolean appInstalledOrNot(String uri) { android.content.pm.PackageManager pm = getPackageManager(); try { pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES); return true; } catch (android.content.pm.PackageManager.NameNotFoundException e) { } return false;
					}
					if (_childValue.containsKey("icon")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("icon").toString())).into(app_icon);
					}
					if (_childValue.containsKey("name")) {
						app_name1.setText(_childValue.get("name").toString());
						app_name2.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("publisher_name")) {
						publisher_name.setText(_childValue.get("publisher_name").toString());
					}
					if (_childValue.containsKey("price")) {
						app_price.setText("$".concat(_childValue.get("price").toString().concat(".00")));
						price = Double.parseDouble(_childValue.get("price").toString());
						premium_tag.setVisibility(View.VISIBLE);
						is_premium_app = true;
					}
					else {
						premium_tag.setVisibility(View.GONE);
						is_premium_app = false;
					}
					if (_childValue.containsKey("size")) {
						app_size.setText(_childValue.get("size").toString());
					}
					if (_childValue.containsKey("likes")) {
						total_likes = Double.parseDouble(_childValue.get("likes").toString());
						likes.setText(_childValue.get("likes").toString());
					}
					else {
						total_likes = 0;
					}
					if (_childValue.containsKey("downloads")) {
						total_downloads = Double.parseDouble(_childValue.get("downloads").toString());
						downloads.setText(_childValue.get("downloads").toString());
					}
					else {
						total_downloads = 0;
					}
					if (_childValue.containsKey("ratings")) {
						total_ratings = Double.parseDouble(_childValue.get("ratings").toString());
						ratings.setText(_childValue.get("ratings").toString().concat("⭐"));
					}
					else {
						total_ratings = 0;
					}
					if (_childValue.containsKey("comments")) {
						total_comments = Double.parseDouble(_childValue.get("comments").toString());
						comments.setText(_childValue.get("comments").toString());
					}
					else {
						total_comments = 0;
					}
					if (_childValue.containsKey("votes")) {
						total_votes = Double.parseDouble(_childValue.get("votes").toString());
						votes.setText(_childValue.get("votes").toString());
					}
					else {
						total_votes = 0;
					}
					if (_childValue.containsKey("age_rating")) {
						age_rating.setText(_childValue.get("age_rating").toString().concat("+"));
					}
					if (_childValue.containsKey("whats_new")) {
						_setTextLink(whats_new, _childValue.get("whats_new").toString());
					}
					else {
						whats_new_back1.setVisibility(View.GONE);
						whats_new_back2.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("about")) {
						_setTextLink(about, _childValue.get("about").toString());
					}
					if (_childValue.containsKey("screenshot1")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot1").toString())).into(screenshot1);
						s1_link = _childValue.get("screenshot1").toString();
					}
					else {
						screenshot1_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot2")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot2").toString())).into(screenshot2);
						s2_link = _childValue.get("screenshot2").toString();
					}
					else {
						screenshot2_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot3")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot3").toString())).into(screenshot3);
						s3_link = _childValue.get("screenshot3").toString();
					}
					else {
						screenshot3_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot4")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot4").toString())).into(screenshot4);
						s4_link = _childValue.get("screenshot4").toString();
					}
					else {
						screenshot4_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot5")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot5").toString())).into(screenshot5);
						s5_link = _childValue.get("screenshot5").toString();
					}
					else {
						screenshot5_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot6")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot6").toString())).into(screenshot6);
						s6_link = _childValue.get("screenshot6").toString();
					}
					else {
						screenshot6_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot7")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot7").toString())).into(screenshot7);
						s7_link = _childValue.get("screenshot7").toString();
					}
					else {
						screenshot7_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot8")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot8").toString())).into(screenshot8);
						s8_link = _childValue.get("screenshot8").toString();
					}
					else {
						screenshot8_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot9")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot9").toString())).into(screenshot9);
						s9_link = _childValue.get("screenshot9").toString();
					}
					else {
						screenshot9_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot10")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot10").toString())).into(screenshot10);
						s10_link = _childValue.get("screenshot10").toString();
					}
					else {
						screenshot10_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("editor")) {
						if (_childValue.get("editor").toString().equals("true")) {
							editor_tag.setVisibility(View.VISIBLE);
						}
						else {
							editor_tag.setVisibility(View.GONE);
						}
					}
					if (_childValue.containsKey("votes")) {
						if (Double.parseDouble(_childValue.get("votes").toString()) > 150) {
							users_tag.setVisibility(View.VISIBLE);
						}
						else {
							users_tag.setVisibility(View.GONE);
						}
					}
					else {
						users_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							verified_tag.setVisibility(View.VISIBLE);
						}
						else {
							verified_tag.setVisibility(View.GONE);
						}
					}
					else {
						verified_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("likes") && _childValue.containsKey("downloads")) {
						if ((Double.parseDouble(_childValue.get("likes").toString()) > 250) && (Double.parseDouble(_childValue.get("downloads").toString()) > 500)) {
							trending_tag.setVisibility(View.VISIBLE);
						}
						else {
							trending_tag.setVisibility(View.GONE);
						}
					}
					else {
						trending_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("likes") && (_childValue.containsKey("downloads") && _childValue.containsKey("ratings"))) {
						if ((Double.parseDouble(_childValue.get("likes").toString()) > 100) && ((Double.parseDouble(_childValue.get("downloads").toString()) > 100) && (Double.parseDouble(_childValue.get("ratings").toString()) > 100))) {
							popular_tag.setVisibility(View.VISIBLE);
						}
						else {
							popular_tag.setVisibility(View.GONE);
						}
					}
					else {
						popular_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("beta")) {
						if (_childValue.get("beta").toString().equals("true")) {
							beta_tag.setVisibility(View.VISIBLE);
						}
						else {
							beta_tag.setVisibility(View.GONE);
						}
					}
					else {
						beta_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("publisher_uid")) {
						publisher_uid = _childValue.get("publisher_uid").toString();
					}
					if (_childValue.containsKey("app_link")) {
						app_link = _childValue.get("app_link").toString();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("app_id"))) {
					if (_childValue.containsKey("package_name")) {
						app_package_name = _childValue.get("package_name").toString();
						boolean isAppInstalled = appInstalledOrNot(_childValue.get("package_name").toString()); 
						
						if(isAppInstalled) {
							
								is_app_installed = true;
							uninstall_btn.setVisibility(View.VISIBLE);
							install_btn.setText("Open");
							
						} else {
							
							is_app_installed = false;
							uninstall_btn.setVisibility(View.GONE);
							
						}}
					
					private boolean appInstalledOrNot(String uri) { android.content.pm.PackageManager pm = getPackageManager(); try { pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES); return true; } catch (android.content.pm.PackageManager.NameNotFoundException e) { } return false;
					}
					if (_childValue.containsKey("icon")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("icon").toString())).into(app_icon);
					}
					if (_childValue.containsKey("name")) {
						app_name1.setText(_childValue.get("name").toString());
						app_name2.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("publisher_name")) {
						publisher_name.setText(_childValue.get("publisher_name").toString());
					}
					if (_childValue.containsKey("price")) {
						app_price.setText("$".concat(_childValue.get("price").toString().concat(".00")));
						price = Double.parseDouble(_childValue.get("price").toString());
						premium_tag.setVisibility(View.VISIBLE);
						is_premium_app = true;
					}
					else {
						premium_tag.setVisibility(View.GONE);
						is_premium_app = false;
					}
					if (_childValue.containsKey("size")) {
						app_size.setText(_childValue.get("size").toString());
					}
					if (_childValue.containsKey("likes")) {
						total_likes = Double.parseDouble(_childValue.get("likes").toString());
						likes.setText(_childValue.get("likes").toString());
					}
					else {
						total_likes = 0;
					}
					if (_childValue.containsKey("downloads")) {
						total_downloads = Double.parseDouble(_childValue.get("downloads").toString());
						downloads.setText(_childValue.get("downloads").toString());
					}
					else {
						total_downloads = 0;
					}
					if (_childValue.containsKey("ratings")) {
						total_ratings = Double.parseDouble(_childValue.get("ratings").toString());
						ratings.setText(_childValue.get("ratings").toString().concat("⭐"));
					}
					else {
						total_ratings = 0;
					}
					if (_childValue.containsKey("comments")) {
						total_comments = Double.parseDouble(_childValue.get("comments").toString());
						comments.setText(_childValue.get("comments").toString());
					}
					else {
						total_comments = 0;
					}
					if (_childValue.containsKey("votes")) {
						total_votes = Double.parseDouble(_childValue.get("votes").toString());
						votes.setText(_childValue.get("votes").toString());
					}
					else {
						total_votes = 0;
					}
					if (_childValue.containsKey("age_rating")) {
						age_rating.setText(_childValue.get("age_rating").toString().concat("+"));
					}
					if (_childValue.containsKey("whats_new")) {
						_setTextLink(whats_new, _childValue.get("whats_new").toString());
					}
					else {
						whats_new_back1.setVisibility(View.GONE);
						whats_new_back2.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("about")) {
						_setTextLink(about, _childValue.get("about").toString());
					}
					if (_childValue.containsKey("screenshot1")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot1").toString())).into(screenshot1);
						s1_link = _childValue.get("screenshot1").toString();
					}
					else {
						screenshot1_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot2")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot2").toString())).into(screenshot2);
						s2_link = _childValue.get("screenshot2").toString();
					}
					else {
						screenshot2_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot3")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot3").toString())).into(screenshot3);
						s3_link = _childValue.get("screenshot3").toString();
					}
					else {
						screenshot3_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot4")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot4").toString())).into(screenshot4);
						s4_link = _childValue.get("screenshot4").toString();
					}
					else {
						screenshot4_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot5")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot5").toString())).into(screenshot5);
						s5_link = _childValue.get("screenshot5").toString();
					}
					else {
						screenshot5_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot6")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot6").toString())).into(screenshot6);
						s6_link = _childValue.get("screenshot6").toString();
					}
					else {
						screenshot6_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot7")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot7").toString())).into(screenshot7);
						s7_link = _childValue.get("screenshot7").toString();
					}
					else {
						screenshot7_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot8")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot8").toString())).into(screenshot8);
						s8_link = _childValue.get("screenshot8").toString();
					}
					else {
						screenshot8_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot9")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot9").toString())).into(screenshot9);
						s9_link = _childValue.get("screenshot9").toString();
					}
					else {
						screenshot9_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("screenshot10")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("screenshot10").toString())).into(screenshot10);
						s10_link = _childValue.get("screenshot10").toString();
					}
					else {
						screenshot10_back.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("editor")) {
						if (_childValue.get("editor").toString().equals("true")) {
							editor_tag.setVisibility(View.VISIBLE);
						}
						else {
							editor_tag.setVisibility(View.GONE);
						}
					}
					if (_childValue.containsKey("votes")) {
						if (Double.parseDouble(_childValue.get("votes").toString()) > 150) {
							users_tag.setVisibility(View.VISIBLE);
						}
						else {
							users_tag.setVisibility(View.GONE);
						}
					}
					else {
						users_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							verified_tag.setVisibility(View.VISIBLE);
						}
						else {
							verified_tag.setVisibility(View.GONE);
						}
					}
					else {
						verified_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("likes") && _childValue.containsKey("downloads")) {
						if ((Double.parseDouble(_childValue.get("likes").toString()) > 250) && (Double.parseDouble(_childValue.get("downloads").toString()) > 500)) {
							trending_tag.setVisibility(View.VISIBLE);
						}
						else {
							trending_tag.setVisibility(View.GONE);
						}
					}
					else {
						trending_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("likes") && (_childValue.containsKey("downloads") && _childValue.containsKey("ratings"))) {
						if ((Double.parseDouble(_childValue.get("likes").toString()) > 100) && ((Double.parseDouble(_childValue.get("downloads").toString()) > 100) && (Double.parseDouble(_childValue.get("ratings").toString()) > 100))) {
							popular_tag.setVisibility(View.VISIBLE);
						}
						else {
							popular_tag.setVisibility(View.GONE);
						}
					}
					else {
						popular_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("beta")) {
						if (_childValue.get("beta").toString().equals("true")) {
							beta_tag.setVisibility(View.VISIBLE);
						}
						else {
							beta_tag.setVisibility(View.GONE);
						}
					}
					else {
						beta_tag.setVisibility(View.GONE);
					}
					if (_childValue.containsKey("publisher_uid")) {
						publisher_uid = _childValue.get("publisher_uid").toString();
					}
					if (_childValue.containsKey("app_link")) {
						app_link = _childValue.get("app_link").toString();
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		games.addChildEventListener(_games_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_theme();
		ratingbar1.setRating((float)0);
		ratingbar1.setNumStars((int)5);
		ratingbar1.setStepSize((float)1);
		progressbar1.setMax((int)100);
		is_busy_downloading = false;
	}
	
	@Override
	public void onBackPressed() {
		_DoubleClickToExit();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (adview1 != null) {
			adview1.destroy();
		}
	}
	public void _theme() {
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			main.setBackgroundColor(0xFF212121);
			app_name2.setTextColor(0xFFFFFFFF);
			app_size.setTextColor(0xFFFFFFFF);
			app_price.setTextColor(0xFFFFFFFF);
			likes.setTextColor(0xFFFFFFFF);
			downloads.setTextColor(0xFFFFFFFF);
			ratings.setTextColor(0xFFFFFFFF);
			comments.setTextColor(0xFFFFFFFF);
			votes.setTextColor(0xFFFFFFFF);
			age_rating.setTextColor(0xFFFFFFFF);
			textview12.setTextColor(0xFFFFFFFF);
			textview13.setTextColor(0xFFFFFFFF);
			textview14.setTextColor(0xFFFFFFFF);
			textview19.setTextColor(0xFFFFFFFF);
			textview15.setTextColor(0xFFFFFFFF);
			textview16.setTextColor(0xFFFFFFFF);
			textview20.setTextColor(0xFFFFFFFF);
			download_progress.setTextColor(0xFFFFFFFF);
			whats_new.setTextColor(0xFFFFFFFF);
			textview25.setTextColor(0xFFFFFFFF);
			textview26.setTextColor(0xFFFFFFFF);
			about.setTextColor(0xFFFFFFFF);
			textview28.setTextColor(0xFFFFFFFF);
			textview29.setTextColor(0xFFFFFFFF);
			_roundcorner(20, 20, 20, 20, "#212121", app_icon);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot1_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot2_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot3_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot4_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot5_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot6_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot7_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot8_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot9_back);
			_roundcorner(15, 15, 15, 15, "#757575", screenshot10_back);
				
		} else {
				
				//Dark mode off
			main.setBackgroundColor(0xFFFFFFFF);
			app_name2.setTextColor(0xFF000000);
			app_size.setTextColor(0xFF000000);
			app_price.setTextColor(0xFF000000);
			likes.setTextColor(0xFF000000);
			downloads.setTextColor(0xFF000000);
			ratings.setTextColor(0xFF000000);
			comments.setTextColor(0xFF000000);
			votes.setTextColor(0xFF000000);
			age_rating.setTextColor(0xFF000000);
			textview12.setTextColor(0xFF000000);
			textview13.setTextColor(0xFF000000);
			textview14.setTextColor(0xFF000000);
			textview19.setTextColor(0xFF000000);
			textview15.setTextColor(0xFF000000);
			textview16.setTextColor(0xFF000000);
			textview20.setTextColor(0xFF000000);
			download_progress.setTextColor(0xFF000000);
			whats_new.setTextColor(0xFF000000);
			textview25.setTextColor(0xFFFFFFFF);
			textview26.setTextColor(0xFF000000);
			about.setTextColor(0xFF000000);
			textview28.setTextColor(0xFF000000);
			textview29.setTextColor(0xFF000000);
			_roundcorner(20, 20, 20, 20, "#FFFFFF", app_icon);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot1_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot2_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot3_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot4_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot5_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot6_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot7_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot8_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot9_back);
			_roundcorner(15, 15, 15, 15, "#EEEEEE", screenshot10_back);
				
		};
		like_icon.setColorFilter(0xFFD50000, PorterDuff.Mode.MULTIPLY);
		download_icon.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		ratings_icon.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		comments_icon.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		votes_icon.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		age_icon.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		back_btn.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(back_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(back_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)200);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(back_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(back_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)200);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		menu_btn.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(menu_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(menu_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)200);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(menu_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(menu_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)200);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		uninstall_btn.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(uninstall_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(uninstall_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)200);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(uninstall_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(uninstall_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)200);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		install_btn.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(install_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(install_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)200);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(install_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)200);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(install_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)200);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		progress_back.setVisibility(View.GONE);
		uninstall_btn.setVisibility(View.GONE);
		_removeScollBar(vscroll2);
		_removeScollBar(hscroll1);
		_removeScollBar(hscroll2);
		_removeScollBar(hscroll3);
		_removeScollBar(comments_listview);
		_ScrollingText(app_name1);
		_ScrollingText(app_name2);
		_ScrollingText(publisher_name);
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _roundcorner(final double _a, final double _b, final double _c, final double _d, final String _BGcolor, final View _view) {
		Double tlr = _a;
		Double trr = _b;
		Double blr = _c;
		Double brr = _d;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_BGcolor));
		_view.setBackground(s);
	}
	
	
	public void _click_effect(final View _view, final String _c) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_c)));
		_view.setClickable(true);
		
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[8];
			        Arrays.fill(outerRadii, 0);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 80);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	public void _DoubleClickToExit() {
		if (is_busy_downloading) {
			number++;
			if (number == 1) {
				FancyToast.makeText(AppViewActivity.this, "Click Again To Cancel Download.", FancyToast.LENGTH_LONG, FancyToast.WARNING, false).show();
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								number = 0;
							}
						});
					}
				};
				_timer.schedule(timer, (int)(2000));
			}
			else {
				finish();
			}
		}
		else {
			finish();
		}
	}
	
	
	public void _setTextLink(final TextView _txt, final String _message) {
		_txt.setText(_message);
		_txt.setClickable(true);
		android.text.util.Linkify.addLinks(_txt, android.text.util.Linkify.ALL);
		_txt.setLinkTextColor(Color.parseColor("#2196F3"));
		_txt.setLinksClickable(true);
	}
	
	
	public void _ScrollingText(final TextView _view) {
		_view.setSingleLine(true);
		_view.setEllipsize(TextUtils.TruncateAt.MARQUEE);
		_view.setSelected(true);
	}
	
	
	public void _open_app(final String _app) {
		Intent launchIntent = getPackageManager().getLaunchIntentForPackage(_app);
		startActivity(launchIntent);
	}
	
	
	public void _uninstallApp(final String _u) {
		Intent intent = new Intent(Intent.ACTION_DELETE);
		intent.setData(Uri.parse("package:".concat(_u)));
		startActivity(intent);
	}
	
	
	public void _extra() {
		
	}
	
	
	public void _Install(final String _apk) {
		String PATH = Environment.getExternalStorageDirectory() + _apk;
		    java.io.File file = new java.io.File(PATH);
		    if(file.exists()) {
				        Intent intent = new Intent(Intent.ACTION_VIEW);
				        intent.setDataAndType(uriFromFile(getApplicationContext(), new java.io.File(PATH)), "application/vnd.android.package-archive");
				        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
				        try {
						            getApplicationContext().startActivity(intent);
						        } catch (ActivityNotFoundException e) {
						            e.printStackTrace();
						            Log.e("TAG", "Error in opening the file!");
						        }
				    }else{
				        
				    }
	}
	Uri uriFromFile(Context context, java.io.File file) {
		    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
				        return androidx.core.content.FileProvider.getUriForFile(context,context.getApplicationContext().getPackageName() + ".provider", file); 
				    } else {
				        return Uri.fromFile(file);
				    }
	}
	
	
	public void _notification(final String _Title, final String _Desc, final double _id, final boolean _sticky) {
		if (_sticky) {
			final Context context = getApplicationContext();
			
			
			NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
			
			Intent intent = new Intent(this, AppViewActivity.class); 
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
			PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0); 
			androidx.core.app.NotificationCompat.Builder builder; 
			
			    int notificationId = (int) _id;
			    String channelId = "channel-03";
			    String channelName = "Downloads";
			    int importance = NotificationManager.IMPORTANCE_HIGH;
			
			    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
				        NotificationChannel mChannel = new NotificationChannel(
				                channelId, channelName, importance);
				        notificationManager.createNotificationChannel(mChannel);
				    }
			
			   
			 androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
			            .setSmallIcon(R.drawable.logo)
			            .setContentTitle(_Title)
			            .setContentText(_Desc)
			            .setAutoCancel(false)
			            .setOngoing(true)
			            .setContentIntent(pendingIntent);
			    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
			    stackBuilder.addNextIntent(intent);
			    PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
			            0,
			            PendingIntent.FLAG_UPDATE_CURRENT
			    );
			    mBuilder.setContentIntent(resultPendingIntent);
			
			    notificationManager.notify(notificationId, mBuilder.build());
			
			
		}
		else {
			final Context context = getApplicationContext();
			
			
			NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
			
			Intent intent = new Intent(this, AopViewActivity.class); 
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
			PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0); 
			androidx.core.app.NotificationCompat.Builder builder; 
			
			    int notificationId = (int) _id;
			    String channelId = "channel-03";
			    String channelName = "Downloads";
			    int importance = NotificationManager.IMPORTANCE_HIGH;
			
			    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
				        NotificationChannel mChannel = new NotificationChannel(
				                channelId, channelName, importance);
				        notificationManager.createNotificationChannel(mChannel);
				    }
			
			  
			 androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
			            .setSmallIcon(R.drawable.logo)
			            .setContentTitle(_Title)
			            .setContentText(_Desc)
			            .setAutoCancel(true)
			            .setOngoing(false)
			            .setContentIntent(pendingIntent);
			    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
			    stackBuilder.addNextIntent(intent);
			    PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
			            0,
			            PendingIntent.FLAG_UPDATE_CURRENT
			    );
			    mBuilder.setContentIntent(resultPendingIntent);
			
			    notificationManager.notify(notificationId, mBuilder.build());
			
		}
	}
	
	public class Comments_listviewAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Comments_listviewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.comment_view, null);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}