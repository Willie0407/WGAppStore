package wg.app.store;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class BooksActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	
	private ArrayList<HashMap<String, Object>> books_listmap = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout scroller_back;
	private LinearLayout nav_line;
	private LinearLayout nav_bar;
	private ScrollView vscroll1;
	private LinearLayout main2;
	private LinearLayout tab;
	private LinearLayout linear2;
	private RecyclerView editor;
	private AdView adview1;
	private LinearLayout linear4;
	private RecyclerView new_updated;
	private AdView adview2;
	private LinearLayout linear7;
	private RecyclerView trending;
	private AdView adview3;
	private LinearLayout linear9;
	private RecyclerView premium;
	private AdView adview4;
	private LinearLayout linear11;
	private RecyclerView top_rated;
	private AdView adview5;
	private LinearLayout linear13;
	private RecyclerView user;
	private AdView adview6;
	private LinearLayout linear15;
	private RecyclerView verified;
	private AdView adview7;
	private LinearLayout linear17;
	private RecyclerView recommended;
	private AdView adview8;
	private LinearLayout linear21;
	private RecyclerView popular;
	private AdView adview9;
	private LinearLayout linear23;
	private RecyclerView downloaded;
	private AdView adview10;
	private LinearLayout linear25;
	private RecyclerView liked;
	private AdView adview11;
	private ImageView tab_drawer_btn;
	private LinearLayout tab_search_back;
	private CircleImageView tab_pic;
	private TextView tab_search_txt;
	private LinearLayout linear3;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear5;
	private ImageView imageview2;
	private TextView textview2;
	private LinearLayout linear8;
	private ImageView imageview3;
	private TextView textview3;
	private LinearLayout linear10;
	private ImageView imageview4;
	private TextView textview4;
	private LinearLayout linear12;
	private ImageView imageview5;
	private TextView textview5;
	private LinearLayout linear14;
	private ImageView imageview6;
	private TextView textview6;
	private LinearLayout linear16;
	private ImageView imageview7;
	private TextView textview7;
	private LinearLayout linear18;
	private ImageView imageview8;
	private TextView textview8;
	private LinearLayout linear22;
	private ImageView imageview10;
	private TextView textview10;
	private LinearLayout linear24;
	private ImageView imageview11;
	private TextView textview11;
	private LinearLayout linear26;
	private ImageView imageview12;
	private TextView textview12;
	private LinearLayout nav_apps_btn;
	private LinearLayout nav_games_btn;
	private LinearLayout nav_books_btn;
	private LinearLayout nav_movies_btn;
	private ImageView nav_apps_icon;
	private TextView nav_apps_txt;
	private ImageView nav_games_icon;
	private TextView nav_games_txt;
	private ImageView nav_books_icon;
	private TextView nav_books_txt;
	private ImageView nav_movies_icon;
	private TextView nav_movies_txt;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear11;
	private LinearLayout _drawer_apps_btn;
	private LinearLayout _drawer_linear12;
	private LinearLayout _drawer_profile_btn;
	private LinearLayout _drawer_linear13;
	private LinearLayout _drawer_wallet_btn;
	private LinearLayout _drawer_linear14;
	private LinearLayout _drawer_inbox_btn;
	private LinearLayout _drawer_linear15;
	private LinearLayout _drawer_upgrade_btn;
	private LinearLayout _drawer_linear16;
	private LinearLayout _drawer_invite_btn;
	private LinearLayout _drawer_linear17;
	private LinearLayout _drawer_settings_btn;
	private LinearLayout _drawer_linear18;
	private CircleImageView _drawer_pic;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_linear4;
	private TextView _drawer_balance;
	private TextView _drawer_plan;
	private TextView _drawer_name;
	private ImageView _drawer_verified_img;
	private ImageView _drawer_imageview1;
	private TextView _drawer_textview1;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview4;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview5;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview6;
	private TextView _drawer_textview6;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview7;
	
	private Intent i = new Intent();
	private SharedPreferences settings;
	private DatabaseReference books = _firebase.getReference("books");
	private ChildEventListener _books_child_listener;
	private DatabaseReference server = _firebase.getReference("server");
	private ChildEventListener _server_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private TimerTask timer;
	private TimerTask timer2;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.books);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(BooksActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		main = findViewById(R.id.main);
		scroller_back = findViewById(R.id.scroller_back);
		nav_line = findViewById(R.id.nav_line);
		nav_bar = findViewById(R.id.nav_bar);
		vscroll1 = findViewById(R.id.vscroll1);
		main2 = findViewById(R.id.main2);
		tab = findViewById(R.id.tab);
		linear2 = findViewById(R.id.linear2);
		editor = findViewById(R.id.editor);
		adview1 = findViewById(R.id.adview1);
		linear4 = findViewById(R.id.linear4);
		new_updated = findViewById(R.id.new_updated);
		adview2 = findViewById(R.id.adview2);
		linear7 = findViewById(R.id.linear7);
		trending = findViewById(R.id.trending);
		adview3 = findViewById(R.id.adview3);
		linear9 = findViewById(R.id.linear9);
		premium = findViewById(R.id.premium);
		adview4 = findViewById(R.id.adview4);
		linear11 = findViewById(R.id.linear11);
		top_rated = findViewById(R.id.top_rated);
		adview5 = findViewById(R.id.adview5);
		linear13 = findViewById(R.id.linear13);
		user = findViewById(R.id.user);
		adview6 = findViewById(R.id.adview6);
		linear15 = findViewById(R.id.linear15);
		verified = findViewById(R.id.verified);
		adview7 = findViewById(R.id.adview7);
		linear17 = findViewById(R.id.linear17);
		recommended = findViewById(R.id.recommended);
		adview8 = findViewById(R.id.adview8);
		linear21 = findViewById(R.id.linear21);
		popular = findViewById(R.id.popular);
		adview9 = findViewById(R.id.adview9);
		linear23 = findViewById(R.id.linear23);
		downloaded = findViewById(R.id.downloaded);
		adview10 = findViewById(R.id.adview10);
		linear25 = findViewById(R.id.linear25);
		liked = findViewById(R.id.liked);
		adview11 = findViewById(R.id.adview11);
		tab_drawer_btn = findViewById(R.id.tab_drawer_btn);
		tab_search_back = findViewById(R.id.tab_search_back);
		tab_pic = findViewById(R.id.tab_pic);
		tab_search_txt = findViewById(R.id.tab_search_txt);
		linear3 = findViewById(R.id.linear3);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		linear5 = findViewById(R.id.linear5);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		linear8 = findViewById(R.id.linear8);
		imageview3 = findViewById(R.id.imageview3);
		textview3 = findViewById(R.id.textview3);
		linear10 = findViewById(R.id.linear10);
		imageview4 = findViewById(R.id.imageview4);
		textview4 = findViewById(R.id.textview4);
		linear12 = findViewById(R.id.linear12);
		imageview5 = findViewById(R.id.imageview5);
		textview5 = findViewById(R.id.textview5);
		linear14 = findViewById(R.id.linear14);
		imageview6 = findViewById(R.id.imageview6);
		textview6 = findViewById(R.id.textview6);
		linear16 = findViewById(R.id.linear16);
		imageview7 = findViewById(R.id.imageview7);
		textview7 = findViewById(R.id.textview7);
		linear18 = findViewById(R.id.linear18);
		imageview8 = findViewById(R.id.imageview8);
		textview8 = findViewById(R.id.textview8);
		linear22 = findViewById(R.id.linear22);
		imageview10 = findViewById(R.id.imageview10);
		textview10 = findViewById(R.id.textview10);
		linear24 = findViewById(R.id.linear24);
		imageview11 = findViewById(R.id.imageview11);
		textview11 = findViewById(R.id.textview11);
		linear26 = findViewById(R.id.linear26);
		imageview12 = findViewById(R.id.imageview12);
		textview12 = findViewById(R.id.textview12);
		nav_apps_btn = findViewById(R.id.nav_apps_btn);
		nav_games_btn = findViewById(R.id.nav_games_btn);
		nav_books_btn = findViewById(R.id.nav_books_btn);
		nav_movies_btn = findViewById(R.id.nav_movies_btn);
		nav_apps_icon = findViewById(R.id.nav_apps_icon);
		nav_apps_txt = findViewById(R.id.nav_apps_txt);
		nav_games_icon = findViewById(R.id.nav_games_icon);
		nav_games_txt = findViewById(R.id.nav_games_txt);
		nav_books_icon = findViewById(R.id.nav_books_icon);
		nav_books_txt = findViewById(R.id.nav_books_txt);
		nav_movies_icon = findViewById(R.id.nav_movies_icon);
		nav_movies_txt = findViewById(R.id.nav_movies_txt);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = _nav_view.findViewById(R.id.linear2);
		_drawer_linear11 = _nav_view.findViewById(R.id.linear11);
		_drawer_apps_btn = _nav_view.findViewById(R.id.apps_btn);
		_drawer_linear12 = _nav_view.findViewById(R.id.linear12);
		_drawer_profile_btn = _nav_view.findViewById(R.id.profile_btn);
		_drawer_linear13 = _nav_view.findViewById(R.id.linear13);
		_drawer_wallet_btn = _nav_view.findViewById(R.id.wallet_btn);
		_drawer_linear14 = _nav_view.findViewById(R.id.linear14);
		_drawer_inbox_btn = _nav_view.findViewById(R.id.inbox_btn);
		_drawer_linear15 = _nav_view.findViewById(R.id.linear15);
		_drawer_upgrade_btn = _nav_view.findViewById(R.id.upgrade_btn);
		_drawer_linear16 = _nav_view.findViewById(R.id.linear16);
		_drawer_invite_btn = _nav_view.findViewById(R.id.invite_btn);
		_drawer_linear17 = _nav_view.findViewById(R.id.linear17);
		_drawer_settings_btn = _nav_view.findViewById(R.id.settings_btn);
		_drawer_linear18 = _nav_view.findViewById(R.id.linear18);
		_drawer_pic = _nav_view.findViewById(R.id.pic);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_linear4 = _nav_view.findViewById(R.id.linear4);
		_drawer_balance = _nav_view.findViewById(R.id.balance);
		_drawer_plan = _nav_view.findViewById(R.id.plan);
		_drawer_name = _nav_view.findViewById(R.id.name);
		_drawer_verified_img = _nav_view.findViewById(R.id.verified_img);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_circleimageview1 = _nav_view.findViewById(R.id.circleimageview1);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview5 = _nav_view.findViewById(R.id.imageview5);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_textview6 = _nav_view.findViewById(R.id.textview6);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		net = new RequestNetwork(this);
		
		tab_drawer_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (_drawer.isDrawerOpen(GravityCompat.START)) {
					_drawer.closeDrawer(GravityCompat.START);
				}
				else {
					_drawer.openDrawer(GravityCompat.START);
				}
			}
		});
		
		tab_pic.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ProfileActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		tab_search_txt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "all");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "editor");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "new");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "trending");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "premium");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "top_rated");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "users");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "verified");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "recommended");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "popular");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "downloaded");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		imageview12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchBooksActivity.class);
				i.putExtra("type", "liked");
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		nav_apps_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), HomeActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				finish();
			}
		});
		
		nav_games_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), GamesActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		nav_movies_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MoviesActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_books_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				books.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						books_listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								books_listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						new_updated.setAdapter(new New_updatedAdapter(books_listmap));
						if (_childValue.containsKey("book_id")) {
							if (_childKey.equals(_childValue.get("book_id").toString())) {
								if (_childValue.containsKey("editor")) {
									if (_childValue.get("editor").toString().equals("true")) {
										editor.setAdapter(new EditorAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes") && _childValue.containsKey("downloads")) {
									if ((Double.parseDouble(_childValue.get("likes").toString()) > 250) && (Double.parseDouble(_childValue.get("downloads").toString()) > 500)) {
										trending.setAdapter(new TrendingAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("price")) {
									premium.setAdapter(new PremiumAdapter(books_listmap));
								}
								if (_childValue.containsKey("ratings")) {
									if (Double.parseDouble(_childValue.get("ratings").toString()) > 310) {
										top_rated.setAdapter(new Top_ratedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("votes")) {
									if (Double.parseDouble(_childValue.get("votes").toString()) > 150) {
										user.setAdapter(new UserAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("verified")) {
									if (_childValue.get("verified").toString().equals("true")) {
										verified.setAdapter(new VerifiedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("recommended")) {
									if (_childValue.get("recommended").toString().equals("true")) {
										recommended.setAdapter(new RecommendedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes") && (_childValue.containsKey("downloads") && _childValue.containsKey("ratings"))) {
									if ((Double.parseDouble(_childValue.get("likes").toString()) > 100) && ((Double.parseDouble(_childValue.get("downloads").toString()) > 100) && (Double.parseDouble(_childValue.get("ratings").toString()) > 100))) {
										popular.setAdapter(new PopularAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("downloads")) {
									if (Double.parseDouble(_childValue.get("downloads").toString()) > 100) {
										downloaded.setAdapter(new DownloadedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes")) {
									if (Double.parseDouble(_childValue.get("likes").toString()) > 100) {
										liked.setAdapter(new LikedAdapter(books_listmap));
									}
								}
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				books.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						books_listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								books_listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						new_updated.setAdapter(new New_updatedAdapter(books_listmap));
						if (_childValue.containsKey("book_id")) {
							if (_childKey.equals(_childValue.get("book_id").toString())) {
								if (_childValue.containsKey("editor")) {
									if (_childValue.get("editor").toString().equals("true")) {
										editor.setAdapter(new EditorAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes") && _childValue.containsKey("downloads")) {
									if ((Double.parseDouble(_childValue.get("likes").toString()) > 250) && (Double.parseDouble(_childValue.get("downloads").toString()) > 500)) {
										trending.setAdapter(new TrendingAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("price")) {
									premium.setAdapter(new PremiumAdapter(books_listmap));
								}
								if (_childValue.containsKey("ratings")) {
									if (Double.parseDouble(_childValue.get("ratings").toString()) > 310) {
										top_rated.setAdapter(new Top_ratedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("votes")) {
									if (Double.parseDouble(_childValue.get("votes").toString()) > 150) {
										user.setAdapter(new UserAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("verified")) {
									if (_childValue.get("verified").toString().equals("true")) {
										verified.setAdapter(new VerifiedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("recommended")) {
									if (_childValue.get("recommended").toString().equals("true")) {
										recommended.setAdapter(new RecommendedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes") && (_childValue.containsKey("downloads") && _childValue.containsKey("ratings"))) {
									if ((Double.parseDouble(_childValue.get("likes").toString()) > 100) && ((Double.parseDouble(_childValue.get("downloads").toString()) > 100) && (Double.parseDouble(_childValue.get("ratings").toString()) > 100))) {
										popular.setAdapter(new PopularAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("downloads")) {
									if (Double.parseDouble(_childValue.get("downloads").toString()) > 100) {
										downloaded.setAdapter(new DownloadedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes")) {
									if (Double.parseDouble(_childValue.get("likes").toString()) > 100) {
										liked.setAdapter(new LikedAdapter(books_listmap));
									}
								}
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				books.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						books_listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								books_listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						new_updated.setAdapter(new New_updatedAdapter(books_listmap));
						if (_childValue.containsKey("book_id")) {
							if (_childKey.equals(_childValue.get("book_id").toString())) {
								if (_childValue.containsKey("editor")) {
									if (_childValue.get("editor").toString().equals("true")) {
										editor.setAdapter(new EditorAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes") && _childValue.containsKey("downloads")) {
									if ((Double.parseDouble(_childValue.get("likes").toString()) > 250) && (Double.parseDouble(_childValue.get("downloads").toString()) > 500)) {
										trending.setAdapter(new TrendingAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("price")) {
									premium.setAdapter(new PremiumAdapter(books_listmap));
								}
								if (_childValue.containsKey("ratings")) {
									if (Double.parseDouble(_childValue.get("ratings").toString()) > 310) {
										top_rated.setAdapter(new Top_ratedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("votes")) {
									if (Double.parseDouble(_childValue.get("votes").toString()) > 150) {
										user.setAdapter(new UserAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("verified")) {
									if (_childValue.get("verified").toString().equals("true")) {
										verified.setAdapter(new VerifiedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("recommended")) {
									if (_childValue.get("recommended").toString().equals("true")) {
										recommended.setAdapter(new RecommendedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes") && (_childValue.containsKey("downloads") && _childValue.containsKey("ratings"))) {
									if ((Double.parseDouble(_childValue.get("likes").toString()) > 100) && ((Double.parseDouble(_childValue.get("downloads").toString()) > 100) && (Double.parseDouble(_childValue.get("ratings").toString()) > 100))) {
										popular.setAdapter(new PopularAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("downloads")) {
									if (Double.parseDouble(_childValue.get("downloads").toString()) > 100) {
										downloaded.setAdapter(new DownloadedAdapter(books_listmap));
									}
								}
								if (_childValue.containsKey("likes")) {
									if (Double.parseDouble(_childValue.get("likes").toString()) > 100) {
										liked.setAdapter(new LikedAdapter(books_listmap));
									}
								}
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		books.addChildEventListener(_books_child_listener);
		
		_server_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		server.addChildEventListener(_server_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("pic")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(tab_pic);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(_drawer_pic);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(_drawer_circleimageview1);
					}
					if (_childValue.containsKey("name")) {
						_drawer_name.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("balance")) {
						_drawer_balance.setText("Wallet: $".concat(_childValue.get("balance").toString().concat(".00")));
					}
					if (_childValue.containsKey("plan")) {
						_drawer_plan.setText("Account: ".concat(_childValue.get("plan").toString()));
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							_drawer_verified_img.setVisibility(View.VISIBLE);
						}
						else {
							_drawer_verified_img.setVisibility(View.GONE);
						}
					}
					else {
						_drawer_verified_img.setVisibility(View.GONE);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("pic")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(tab_pic);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(_drawer_pic);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(_drawer_circleimageview1);
					}
					if (_childValue.containsKey("name")) {
						_drawer_name.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("balance")) {
						_drawer_balance.setText("Wallet: $".concat(_childValue.get("balance").toString().concat(".00")));
					}
					if (_childValue.containsKey("plan")) {
						_drawer_plan.setText("Account: ".concat(_childValue.get("plan").toString()));
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							_drawer_verified_img.setVisibility(View.VISIBLE);
						}
						else {
							_drawer_verified_img.setVisibility(View.GONE);
						}
					}
					else {
						_drawer_verified_img.setVisibility(View.GONE);
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("pic")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(tab_pic);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(_drawer_pic);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(_drawer_circleimageview1);
					}
					if (_childValue.containsKey("name")) {
						_drawer_name.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("balance")) {
						_drawer_balance.setText("Wallet: $".concat(_childValue.get("balance").toString().concat(".00")));
					}
					if (_childValue.containsKey("plan")) {
						_drawer_plan.setText("Account: ".concat(_childValue.get("plan").toString()));
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							_drawer_verified_img.setVisibility(View.VISIBLE);
						}
						else {
							_drawer_verified_img.setVisibility(View.GONE);
						}
					}
					else {
						_drawer_verified_img.setVisibility(View.GONE);
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_drawer_apps_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ManageAppsActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_drawer_profile_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ProfileActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_drawer_wallet_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), WalletActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_drawer_inbox_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), InboxActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_drawer_upgrade_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), UpgradeActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_drawer_invite_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), InviteFriendsActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		_drawer_settings_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SettingsActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_theme();
		_check();
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			finish();
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (adview1 != null) {
			adview1.destroy();
		}
	}
	public void _theme() {
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int[] colorsCRNVM = { Color.parseColor("#FF5722"), Color.parseColor("#FF5722") }; android.graphics.drawable.GradientDrawable CRNVM = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNVM);
		CRNVM.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)20,(int)20,(int)20,(int)20});
		CRNVM.setStroke((int) 0, Color.parseColor("#000000"));
		tab.setElevation((float) 5);
		tab.setBackground(CRNVM);
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =BooksActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFF5722);
			}
			main.setBackgroundColor(0xFF212121);
			nav_bar.setBackgroundColor(0xFF212121);
			nav_line.setBackgroundColor(0xFF757575);
			textview1.setTextColor(0xFFFFFFFF);
			textview2.setTextColor(0xFFFFFFFF);
			textview3.setTextColor(0xFFFFFFFF);
			textview4.setTextColor(0xFFFFFFFF);
			textview5.setTextColor(0xFFFFFFFF);
			textview6.setTextColor(0xFFFFFFFF);
			textview7.setTextColor(0xFFFFFFFF);
			textview8.setTextColor(0xFFFFFFFF);
			textview10.setTextColor(0xFFFFFFFF);
			textview11.setTextColor(0xFFFFFFFF);
			textview12.setTextColor(0xFFFFFFFF);
			nav_apps_txt.setTextColor(0xFFE0E0E0);
			nav_games_txt.setTextColor(0xFFE0E0E0);
			nav_books_txt.setTextColor(0xFFFFFFFF);
			nav_movies_txt.setTextColor(0xFFE0E0E0);
			nav_apps_icon.setImageResource(R.drawable.ic_apps_grey);
			nav_games_icon.setImageResource(R.drawable.ic_gamepad_grey);
			nav_books_icon.setImageResource(R.drawable.ic_local_library_white);
			nav_movies_icon.setImageResource(R.drawable.ic_album_grey);
			_drawer_vscroll1.setBackgroundColor(0xFF212121);
				
		} else {
				
				//Dark mode off
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =BooksActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFF5722);
			}
			main.setBackgroundColor(0xFFFFFFFF);
			nav_bar.setBackgroundColor(0xFFFFFFFF);
			nav_line.setBackgroundColor(0xFF9E9E9E);
			textview1.setTextColor(0xFF000000);
			textview2.setTextColor(0xFF000000);
			textview3.setTextColor(0xFF000000);
			textview4.setTextColor(0xFF000000);
			textview5.setTextColor(0xFF000000);
			textview6.setTextColor(0xFF000000);
			textview7.setTextColor(0xFF000000);
			textview8.setTextColor(0xFF000000);
			textview10.setTextColor(0xFF000000);
			textview11.setTextColor(0xFF000000);
			textview12.setTextColor(0xFF000000);
			nav_apps_txt.setTextColor(0xFF9E9E9E);
			nav_games_txt.setTextColor(0xFF9E9E9E);
			nav_books_txt.setTextColor(0xFF000000);
			nav_movies_txt.setTextColor(0xFF9E9E9E);
			nav_apps_icon.setImageResource(R.drawable.ic_apps_grey);
			nav_games_icon.setImageResource(R.drawable.ic_gamepad_grey);
			nav_books_icon.setImageResource(R.drawable.ic_local_library_black);
			nav_movies_icon.setImageResource(R.drawable.ic_album_grey);
			_drawer_vscroll1.setBackgroundColor(0xFFFFFFFF);
				
		};
		editor.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		new_updated.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		trending.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		premium.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		top_rated.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		user.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		verified.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		recommended.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		popular.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		downloaded.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		liked.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		_removeScollBar(vscroll1);
		_removeScollBar(editor);
		_removeScollBar(new_updated);
		_removeScollBar(trending);
		_removeScollBar(premium);
		_removeScollBar(top_rated);
		_removeScollBar(user);
		_removeScollBar(verified);
		_removeScollBar(recommended);
		_removeScollBar(popular);
		_removeScollBar(downloaded);
		_removeScollBar(liked);
		_removeScollBar(_drawer_vscroll1);
		tab_drawer_btn.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(tab_drawer_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(tab_drawer_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(tab_drawer_btn);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(tab_drawer_btn);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		tab_pic.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(tab_pic);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(tab_pic);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(tab_pic);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(tab_pic);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview1);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview1);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview1);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview1);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview2.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview2);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview2);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview2);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview2);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview3.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview3);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview3);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview3);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview3);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview4.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview4);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview4);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview4);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview4);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview5.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview5);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview5);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview5);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview5);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview6.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview6);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview6);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview6);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview6);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview7.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview7);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview7);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview7);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview7);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview8.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview8);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview8);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview8);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview8);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview10.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview10);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview10);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview10);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview10);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview11.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview11);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview11);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview11);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview11);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		imageview12.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
					case MotionEvent.ACTION_DOWN:{
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview12);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues(0.9f);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview12);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues(0.9f);
						scaleY.setDuration((int)250);
						scaleY.start();
						break;
					}
					case MotionEvent.ACTION_UP:{
						
						ObjectAnimator scaleX = new ObjectAnimator();
						scaleX.setTarget(imageview12);
						scaleX.setPropertyName("scaleX");
						scaleX.setFloatValues((float)1);
						scaleX.setDuration((int)250);
						scaleX.start();
						
						ObjectAnimator scaleY = new ObjectAnimator();
						scaleY.setTarget(imageview12);
						scaleY.setPropertyName("scaleY");
						scaleY.setFloatValues((float)1);
						scaleY.setDuration((int)250);
						scaleY.start();
						
						break;
					}
				}
				return false;
			}
		});
		int[] colorsCRNJS = { Color.parseColor("#FF5722"), Color.parseColor("#FF5722") }; android.graphics.drawable.GradientDrawable CRNJS = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNJS);
		CRNJS.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)360,(int)360,(int)15,(int)15});
		CRNJS.setStroke((int) 0, Color.parseColor("#000000"));
		_drawer_linear2.setElevation((float) 5);
		_drawer_linear2.setBackground(CRNJS);
		_drawer_imageview1.setColorFilter(0xFFFF5722, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview3.setColorFilter(0xFFFF5722, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview4.setColorFilter(0xFFFF5722, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview5.setColorFilter(0xFFFF5722, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview6.setColorFilter(0xFFFF5722, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview7.setColorFilter(0xFFFF5722, PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _check() {
		net.startRequestNetwork(RequestNetworkController.GET, "https://google.com/", "A", _net_request_listener);
	}
	
	
	public void _roundcorner(final double _a, final double _b, final double _c, final double _d, final String _BGcolor, final View _view) {
		Double tlr = _a;
		Double trr = _b;
		Double blr = _c;
		Double brr = _d;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_BGcolor));
		_view.setBackground(s);
	}
	
	
	public void _ScrollingText(final TextView _view) {
		_view.setSingleLine(true);
		_view.setEllipsize(TextUtils.TruncateAt.MARQUEE);
		_view.setSelected(true);
	}
	
	
	public void _BadgetView(final ImageView _Imageview, final String _setTextColor, final String _setBackgroundColor, final double _setTextSize, final double _setWidth, final double _setHeight, final double _setSpace1, final double _setSpace2, final double _setBadgeCount) {
		     BadgeFactory.create(this)
		    .setTextColor(Color.parseColor(_setTextColor))
		    .setWidthAndHeight((int)_setWidth,(int)_setHeight)
		    .setBadgeBackground(Color.parseColor(_setBackgroundColor))
		    .setTextSize((int)_setTextSize)
		    .setBadgeGravity(Gravity.RIGHT|Gravity.TOP)
		    .setBadgeCount((int)_setBadgeCount)
		    .setShape(BadgeView.SHAPE_CIRCLE)
		    .setSpace((int)_setSpace1,(int)_setSpace2)
		    .bind(_Imageview);
	}
	public static class BadgeFactory {
		    public static BadgeView createDot(Context context){
			        return  new BadgeView(context).setWidthAndHeight(10,10).setTextSize(0).setBadgeGravity(Gravity.RIGHT| Gravity.TOP).setShape(BadgeView.SHAPE_CIRCLE);
			    }
		    public static BadgeView createCircle(Context context){
			        return  new BadgeView(context).setWidthAndHeight(20,20).setTextSize(12).setBadgeGravity(Gravity.RIGHT| Gravity.TOP).setShape(BadgeView.SHAPE_CIRCLE);
			    }
		    public static BadgeView createRectangle(Context context){
			        return  new BadgeView(context).setWidthAndHeight(25,20).setTextSize(12).setBadgeGravity(Gravity.RIGHT| Gravity.TOP).setShape(BadgeView.SHAPE_RECTANGLE);
			    }
		    public static BadgeView createOval(Context context){
			        return  new BadgeView(context).setWidthAndHeight(25,20).setTextSize(12).setBadgeGravity(Gravity.RIGHT| Gravity.TOP).setShape(BadgeView.SHAPE_OVAL);
			    }
		    public static BadgeView createSquare(Context context){
			        return  new BadgeView(context).setWidthAndHeight(20,20).setTextSize(12).setBadgeGravity(Gravity.RIGHT| Gravity.TOP).setShape(BadgeView.SHAPE_SQUARE);
			    }
		    public static BadgeView createRoundRect(Context context){
			        return  new BadgeView(context).setWidthAndHeight(25,20).setTextSize(12).setBadgeGravity(Gravity.RIGHT| Gravity.TOP).setShape(BadgeView.SHAPTE_ROUND_RECTANGLE);
			    }
		    public static BadgeView create(Context context){
			        return  new BadgeView(context);
			    }
		
	}
	
	public static class BadgeView extends View {
		    private Paint numberPaint;
		    private Paint backgroundPaint;
		    public static final int SHAPE_CIRCLE = 1;
		    public static final int SHAPE_RECTANGLE = 2;
		    public static final int SHAPE_OVAL = 3;
		    public static final int SHAPTE_ROUND_RECTANGLE = 4;
		    public static final int SHAPE_SQUARE = 5;
		    private int currentShape = SHAPE_CIRCLE;
		    private int defaultTextColor = Color.WHITE;
		    private int defaultTextSize;
		    private int defaultBackgroundColor = Color.RED;
		    private String showText = "";
		    private int badgeGravity = Gravity.RIGHT | Gravity.TOP;
		    private int leftMargin = 0;
		    private int topMargin = 0;
		    private int bottomMargin = 0;
		    private int rightMargin = 0;
		    private boolean hasBind=false;
		    private int horiontalSpace=0;
		    private int verticalSpace=0;
		    public BadgeView(Context context) {
			        super(context);
			        init(context);
			    }
		    public BadgeView(Context context, AttributeSet attrs) {
			        super(context, attrs);
			        init(context);
			    }
		    public BadgeView(Context context, AttributeSet attrs, int defStyleAttr) {
			        super(context, attrs, defStyleAttr);
			        init(context);
			    }
		    public BadgeView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
			        super(context, attrs, defStyleAttr, defStyleRes);
			        init(context);
			    }
		    private void init(Context context) {
			        defaultTextSize = dip2px(context, 1);
			        numberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			        numberPaint.setColor(defaultTextColor);
			        numberPaint.setStyle(Paint.Style.FILL);
			        numberPaint.setTextSize(defaultTextSize);
			        numberPaint.setTextAlign(Paint.Align.CENTER);
			        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			        backgroundPaint.setColor(defaultBackgroundColor);
			        backgroundPaint.setStyle(Paint.Style.FILL);
			        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
			        params.gravity = badgeGravity;
			        setLayoutParams(params);
			    }
		    @Override
		    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
			        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			    }
		    @Override
		    protected void onDraw(Canvas canvas) {
			        super.onDraw(canvas);
			        RectF rectF = new RectF(0, 0, getMeasuredWidth(), getMeasuredHeight());
			        Paint.FontMetrics fontMetrics = numberPaint.getFontMetrics();
			        float textH = fontMetrics.descent - fontMetrics.ascent;
			        switch (currentShape) {
				            case SHAPE_CIRCLE:
				                canvas.drawCircle(getMeasuredWidth() / 2f, getMeasuredHeight() / 2f, getMeasuredWidth() / 2, backgroundPaint);
				                canvas.drawText(showText, getMeasuredWidth() / 2f, getMeasuredHeight() / 2f + (textH / 2f - fontMetrics.descent), numberPaint);
				                break;
				            case SHAPE_OVAL:
				
				                canvas.drawOval(rectF, backgroundPaint);
				                canvas.drawText(showText, getMeasuredWidth() / 2f, getMeasuredHeight() / 2f + (textH / 2f - fontMetrics.descent), numberPaint);
				                break;
				            case SHAPE_RECTANGLE:
				                canvas.drawRect(rectF, backgroundPaint);
				                canvas.drawText(showText, getMeasuredWidth() / 2f, getMeasuredHeight() / 2f + (textH / 2f - fontMetrics.descent), numberPaint);
				                break;
				            case SHAPE_SQUARE:
				                int sideLength = Math.min(getMeasuredHeight(), getMeasuredWidth());
				                RectF squareF = new RectF(0, 0, sideLength, sideLength);
				                canvas.drawRect(squareF, backgroundPaint);
				                canvas.drawText(showText, sideLength / 2f, sideLength / 2f + (textH / 2f - fontMetrics.descent), numberPaint);
				                break;
				            case SHAPTE_ROUND_RECTANGLE:
				                canvas.drawRoundRect(rectF, dip2px(getContext(), 5), dip2px(getContext(), 5), backgroundPaint);
				                canvas.drawText(showText, getMeasuredWidth() / 2f, getMeasuredHeight() / 2f + (textH / 2f - fontMetrics.descent), numberPaint);
				                break;
				        }
			
			    }
		    private int dip2px(Context context, int dip) {
			        return (int) (dip * getContext().getResources().getDisplayMetrics().density + 0.5f);
			    }
		    private int sp2px(Context context, float spValue) {
			        final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
			        return (int) (spValue * fontScale + 0.5f);
			    }
		    public BadgeView setShape(int shape) {
			        currentShape = shape;
			        invalidate();
			        return this;
			    }
		    public BadgeView setWidthAndHeight(int w, int h) {
			        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) getLayoutParams();
			        params.width = dip2px(getContext(), w);
			        params.height = dip2px(getContext(), h);
			        setLayoutParams(params);
			        return this;
			    }
		    public BadgeView setWidth(int sp) {
			        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) getLayoutParams();
			        params.width = dip2px(getContext(), sp);
			        setLayoutParams(params);
			        return this;
			
			    }
		    public BadgeView setHeight(int sp) {
			        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) getLayoutParams();
			        params.height = dip2px(getContext(), sp);
			        setLayoutParams(params);
			        return this;
			    }
		    @Deprecated
		    public BadgeView setMargin(int left, int top, int right, int bottom) {
			        leftMargin = dip2px(getContext(), left);
			        bottomMargin = dip2px(getContext(), bottom);
			        topMargin = dip2px(getContext(), top);
			        rightMargin = dip2px(getContext(), right);
			        invalidate();
			        return this;
			    }
		    public BadgeView setSpace(int horitontal, int vertical){
			        horiontalSpace=dip2px(getContext(), horitontal);
			        verticalSpace=dip2px(getContext(), vertical);
			        invalidate();
			        return  this;
			    }
		    public BadgeView setTextSize(int sp) {
			        defaultTextSize = sp2px(getContext(), sp);
			        numberPaint.setTextSize(sp2px(getContext(), sp));
			        invalidate();
			        return this;
			    }
		    public BadgeView setTextColor(int color) {
			        defaultTextColor = color;
			        numberPaint.setColor(color);
			        invalidate();
			        return this;
			    }
		    public BadgeView setBadgeBackground(int color) {
			        defaultBackgroundColor = color;
			        backgroundPaint.setColor(color);
			        invalidate();
			        return this;
			    }
		    public BadgeView setBadgeCount(int count) {
			        showText = String.valueOf(count);
			        invalidate();
			        return this;
			    }
		    public BadgeView setBadgeCount(String count) {
			        showText = count;
			        invalidate();
			        return this;
			    }
		    public BadgeView setBadgeGravity(int gravity) {
			        badgeGravity = gravity;
			        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) getLayoutParams();
			        params.gravity = gravity;
			        setLayoutParams(params);
			        return this;
			    }
		    public BadgeView bind(View view) {
			        if (getParent() != null)
			            ((ViewGroup) getParent()).removeView(this);
			        if (view == null)
			            return this;
			        if ((view.getParent() instanceof FrameLayout)&&hasBind==true) {
				            ((FrameLayout) view.getParent()).addView(this);
				            return this;
				        } else if (view.getParent() instanceof ViewGroup) {
				            ViewGroup parentContainer = (ViewGroup) view.getParent();
				            int viewIndex = ((ViewGroup) view.getParent()).indexOfChild(view);
				            ((ViewGroup) view.getParent()).removeView(view);
				            FrameLayout container = new FrameLayout(getContext());
				            ViewGroup.LayoutParams containerParams = view.getLayoutParams();
				            int origionHeight=containerParams.height;
				            int origionWidth=containerParams.width;
				            FrameLayout.LayoutParams viewLayoutParams =new FrameLayout.LayoutParams( origionWidth, origionHeight);
				            if(origionHeight==ViewGroup.LayoutParams.WRAP_CONTENT){
					                containerParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
					                viewLayoutParams.topMargin=topMargin;
					                viewLayoutParams.bottomMargin=bottomMargin;
					            }else{
					                containerParams.height =origionHeight+topMargin+bottomMargin+verticalSpace;
					            }
				            if(origionWidth==ViewGroup.LayoutParams.WRAP_CONTENT){
					                containerParams.width = ViewGroup.LayoutParams.WRAP_CONTENT;
					                viewLayoutParams.leftMargin=leftMargin;
					                viewLayoutParams.rightMargin=rightMargin;
					            }else{
					                containerParams.width=origionWidth+rightMargin+horiontalSpace+leftMargin;
					            }
				            container.setLayoutParams(containerParams);
				            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) getLayoutParams();
				            if(params.gravity==(Gravity.RIGHT|Gravity.TOP)||params.gravity==Gravity.RIGHT||params.gravity==Gravity.TOP){
					                view.setPadding(0,verticalSpace,horiontalSpace,0);
					                viewLayoutParams.gravity=Gravity.LEFT|Gravity.BOTTOM;
					            }else if(params.gravity==(Gravity.LEFT|Gravity.TOP)||params.gravity==Gravity.LEFT||params.gravity==Gravity.TOP){
					                view.setPadding(horiontalSpace,verticalSpace,0,0);
					                viewLayoutParams.gravity=Gravity.RIGHT|Gravity.BOTTOM;
					            }else if(params.gravity==(Gravity.LEFT|Gravity.BOTTOM)){
					                view.setPadding(horiontalSpace,0,0,verticalSpace);
					                viewLayoutParams.gravity=Gravity.RIGHT|Gravity.TOP;
					            }else if(params.gravity==(Gravity.RIGHT|Gravity.BOTTOM)){
					                view.setPadding(0,0,horiontalSpace,verticalSpace);
					                viewLayoutParams.gravity=Gravity.LEFT|Gravity.TOP;
					            }else{
					                view.setPadding(0,verticalSpace,horiontalSpace,0);
					                viewLayoutParams.gravity=Gravity.LEFT|Gravity.BOTTOM;
					            }
				            view.setLayoutParams(viewLayoutParams);
				            container.setId(view.getId());
				            container.addView(view);
				            container.addView(this);
				            parentContainer.addView(container, viewIndex);
				            hasBind=true;
				        } else if (view.getParent() == null) {
				            Log.e("badgeview", "View must have a parent");
				        }
			        return this;
			    }
		    public boolean unbind() {
			        if (getParent() != null) {
						((ViewGroup) getParent()).removeView(this);
				            return true;
				        }
			        return false;
			    }
		    public String getBadgeCount() {
			        return showText;
			    }
	}
	
	{
	}
	
	public class EditorAdapter extends RecyclerView.Adapter<EditorAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public EditorAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class New_updatedAdapter extends RecyclerView.Adapter<New_updatedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public New_updatedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class TrendingAdapter extends RecyclerView.Adapter<TrendingAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public TrendingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class PremiumAdapter extends RecyclerView.Adapter<PremiumAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public PremiumAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText("$".concat(books_listmap.get((int)_position).get("price").toString().concat(".00")));
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Top_ratedAdapter extends RecyclerView.Adapter<Top_ratedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Top_ratedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public UserAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class VerifiedAdapter extends RecyclerView.Adapter<VerifiedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public VerifiedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class RecommendedAdapter extends RecyclerView.Adapter<RecommendedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RecommendedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class PopularAdapter extends RecyclerView.Adapter<PopularAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public PopularAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class DownloadedAdapter extends RecyclerView.Adapter<DownloadedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public DownloadedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class LikedAdapter extends RecyclerView.Adapter<LikedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public LikedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.books_view, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView big_img = _view.findViewById(R.id.big_img);
			final ImageView big_img2 = _view.findViewById(R.id.big_img2);
			final ImageView big_img3 = _view.findViewById(R.id.big_img3);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView author = _view.findViewById(R.id.author);
			final TextView size = _view.findViewById(R.id.size);
			
			_ScrollingText(name);
			_ScrollingText(author);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
			int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
			if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
					
					//Dark Mode On
				int[] colorsCRNMN = { Color.parseColor("#212122"), Color.parseColor("#212122") }; android.graphics.drawable.GradientDrawable CRNMN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMN);
				CRNMN.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNMN.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNMN);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNTA = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNTA = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTA);
				CRNTA.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNTA.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNTA);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#212121", icon);
				big_img2.setBackgroundColor(0xFF212121);
				linear1.setBackgroundColor(0xFF212121);
				name.setTextColor(0xFFFFFFFF);
				size.setTextColor(0xFFEEEEEE);
				author.setTextColor(0xFF2196F3);
					
			} else {
					
					//Dark mode off
				int[] colorsCRNUW = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNUW = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUW);
				CRNUW.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
				CRNUW.setStroke((int) 0, Color.parseColor("#000000"));
				big_img.setElevation((float) 0);
				big_img.setBackground(CRNUW);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNKC = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNKC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNKC);
				CRNKC.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				CRNKC.setStroke((int) 0, Color.parseColor("#000000"));
				big_img3.setElevation((float) 0);
				big_img3.setBackground(CRNKC);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_roundcorner(15, 15, 15, 15, "#FFFFFF", icon);
				big_img2.setBackgroundColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFFFFFFFF);
				name.setTextColor(0xFF000000);
				size.setTextColor(0xFF757575);
				author.setTextColor(0xFF2196F3);
					
			};
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("icon").toString())).into(icon);
			name.setText(books_listmap.get((int)_position).get("name").toString());
			size.setText(books_listmap.get((int)_position).get("size").toString());
			author.setText(books_listmap.get((int)_position).get("author").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s1").toString())).into(big_img);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s2").toString())).into(big_img2);
			Glide.with(getApplicationContext()).load(Uri.parse(books_listmap.get((int)_position).get("s3").toString())).into(big_img3);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			big_img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
			name.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), BookViewActivity.class);
					i.putExtra("book_id", books_listmap.get((int)_position).get("book_id").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}