package wg.app.store;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.provider.Settings.Secure;

public class SecurityCheckActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double number = 0;
	private HashMap<String, Object> phones_map = new HashMap<>();
	
	private LinearLayout main;
	private LinearLayout linear2;
	private ImageView img;
	private ProgressBar progressbar1;
	private TextView title;
	private TextView subtitle;
	private Button support_button;
	private TextView textview1;
	
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private TimerTask t;
	private DatabaseReference phones = _firebase.getReference("phones");
	private ChildEventListener _phones_child_listener;
	private SharedPreferences settings;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private Calendar cal = Calendar.getInstance();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.security_check);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		linear2 = findViewById(R.id.linear2);
		img = findViewById(R.id.img);
		progressbar1 = findViewById(R.id.progressbar1);
		title = findViewById(R.id.title);
		subtitle = findViewById(R.id.subtitle);
		support_button = findViewById(R.id.support_button);
		textview1 = findViewById(R.id.textview1);
		d = new AlertDialog.Builder(this);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		net = new RequestNetwork(this);
		
		support_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SupportActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("Security Check Help");
				d.setIcon(R.drawable.logo);
				d.setMessage("Security Check Was Added To The App To Prevent Hackers From Accessing Your Account And To Keep It Safe.\n\nSecurity Check Facts:\n\n1. How To Approve A Security Check.\nTo Approve A Device To Pass The Security Check You Can Go To Settings>Devices> And You'll See An Active Device, Just Click Approve To Approve Your New Device,\n\n2. Can't Access Settings.\nIf You Can't Access The Settings To Approve Your App Then You Have To Contact Support To Approve Your New Device,\n\n3. How To Deactivate Security Check.\nTo Deactivate Security Check Go To Settings And Deactivate Security Check,");
				d.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		_phones_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				cal = Calendar.getInstance();
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("android_id")) {
						if (//import android.provider.Settings.Secure;
						Secure.getString(SecurityCheckActivity.this.getContentResolver(), Secure.ANDROID_ID).equals(_childValue.get("android_id").toString())) {
							i.setClass(getApplicationContext(), HomeActivity.class);
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
						}
						else {
							if (_childValue.containsKey("approved")) {
								if (_childValue.get("approved").toString().equals("true")) {
									i.setClass(getApplicationContext(), HomeActivity.class);
									i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
									startActivity(i);
									phones_map = new HashMap<>();
									phones_map.put("build_type", Build.TYPE);
									phones_map.put("build_tags", Build.TAGS);
									phones_map.put("build_user", Build.USER);
									phones_map.put("build_unknown", Build.UNKNOWN);
									phones_map.put("build_id", Build.ID);
									phones_map.put("build_product", Build.PRODUCT);
									phones_map.put("build_display", Build.DISPLAY);
									phones_map.put("build_fingerprint", Build.FINGERPRINT);
									phones_map.put("build_cpu_abi", Build.CPU_ABI);
									phones_map.put("build_host", Build.HOST);
									phones_map.put("build_radio", Build.RADIO);
									phones_map.put("build_hardware", Build.HARDWARE);
									phones_map.put("build_serial", Build.SERIAL);
									phones_map.put("build_bootloader", Build.BOOTLOADER);
									phones_map.put("build_board", Build.BOARD);
									phones_map.put("build_version_security_patch", Build.VERSION.SECURITY_PATCH);
									phones_map.put("build_brand", Build.BRAND);
									phones_map.put("build_version_sdk", Build.VERSION.SDK);
									phones_map.put("build_manufacturer", Build.MANUFACTURER);
									phones_map.put("build_model", Build.MODEL);
									phones_map.put("build_version_release", Build.VERSION.RELEASE);
									phones_map.put("android_id", //import android.provider.Settings.Secure;
									Secure.getString(SecurityCheckActivity.this.getContentResolver(), Secure.ANDROID_ID));
									phones_map.put("last_live_time", new SimpleDateFormat("hh:mm EEE, d MMM").format(cal.getTime()));
									phones_map.put("approved", "true");
									phones.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(phones_map);
									phones_map.clear();
								}
								else {
									title.setText("Device Doesn't Match");
									subtitle.setText("Our Server Detected That This Device Doesn't Match The Registred Device,\n\nTo Approve This Device Go To Settings>Phones> And Click Approve, Or Contact Support To Approve This Device,");
									title.setTextColor(0xFFD50000);
									subtitle.setTextColor(0xFF000000);
									support_button.setVisibility(View.VISIBLE);
									progressbar1.setVisibility(View.GONE);
								}
							}
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				cal = Calendar.getInstance();
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("android_id")) {
						if (//import android.provider.Settings.Secure;
						Secure.getString(SecurityCheckActivity.this.getContentResolver(), Secure.ANDROID_ID).equals(_childValue.get("android_id").toString())) {
							i.setClass(getApplicationContext(), HomeActivity.class);
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
						}
						else {
							if (_childValue.containsKey("approved")) {
								if (_childValue.get("approved").toString().equals("true")) {
									i.setClass(getApplicationContext(), HomeActivity.class);
									i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
									startActivity(i);
									phones_map = new HashMap<>();
									phones_map.put("build_type", Build.TYPE);
									phones_map.put("build_tags", Build.TAGS);
									phones_map.put("build_user", Build.USER);
									phones_map.put("build_unknown", Build.UNKNOWN);
									phones_map.put("build_id", Build.ID);
									phones_map.put("build_product", Build.PRODUCT);
									phones_map.put("build_display", Build.DISPLAY);
									phones_map.put("build_fingerprint", Build.FINGERPRINT);
									phones_map.put("build_cpu_abi", Build.CPU_ABI);
									phones_map.put("build_host", Build.HOST);
									phones_map.put("build_radio", Build.RADIO);
									phones_map.put("build_hardware", Build.HARDWARE);
									phones_map.put("build_serial", Build.SERIAL);
									phones_map.put("build_bootloader", Build.BOOTLOADER);
									phones_map.put("build_board", Build.BOARD);
									phones_map.put("build_version_security_patch", Build.VERSION.SECURITY_PATCH);
									phones_map.put("build_brand", Build.BRAND);
									phones_map.put("build_version_sdk", Build.VERSION.SDK);
									phones_map.put("build_manufacturer", Build.MANUFACTURER);
									phones_map.put("build_model", Build.MODEL);
									phones_map.put("build_version_release", Build.VERSION.RELEASE);
									phones_map.put("android_id", //import android.provider.Settings.Secure;
									Secure.getString(SecurityCheckActivity.this.getContentResolver(), Secure.ANDROID_ID));
									phones_map.put("last_live_time", new SimpleDateFormat("hh:mm EEE, d MMM").format(cal.getTime()));
									phones_map.put("approved", "true");
									phones.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(phones_map);
									phones_map.clear();
								}
								else {
									title.setText("Device Doesn't Match");
									subtitle.setText("Our Server Detected That This Device Doesn't Match The Registred Device,\n\nTo Approve This Device Go To Settings>Phones> And Click Approve, Or Contact Support To Approve This Device,");
									title.setTextColor(0xFFD50000);
									subtitle.setTextColor(0xFF000000);
									support_button.setVisibility(View.VISIBLE);
									progressbar1.setVisibility(View.GONE);
								}
							}
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				cal = Calendar.getInstance();
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("android_id")) {
						if (//import android.provider.Settings.Secure;
						Secure.getString(SecurityCheckActivity.this.getContentResolver(), Secure.ANDROID_ID).equals(_childValue.get("android_id").toString())) {
							i.setClass(getApplicationContext(), HomeActivity.class);
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
						}
						else {
							if (_childValue.containsKey("approved")) {
								if (_childValue.get("approved").toString().equals("true")) {
									i.setClass(getApplicationContext(), HomeActivity.class);
									i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
									startActivity(i);
									phones_map = new HashMap<>();
									phones_map.put("build_type", Build.TYPE);
									phones_map.put("build_tags", Build.TAGS);
									phones_map.put("build_user", Build.USER);
									phones_map.put("build_unknown", Build.UNKNOWN);
									phones_map.put("build_id", Build.ID);
									phones_map.put("build_product", Build.PRODUCT);
									phones_map.put("build_display", Build.DISPLAY);
									phones_map.put("build_fingerprint", Build.FINGERPRINT);
									phones_map.put("build_cpu_abi", Build.CPU_ABI);
									phones_map.put("build_host", Build.HOST);
									phones_map.put("build_radio", Build.RADIO);
									phones_map.put("build_hardware", Build.HARDWARE);
									phones_map.put("build_serial", Build.SERIAL);
									phones_map.put("build_bootloader", Build.BOOTLOADER);
									phones_map.put("build_board", Build.BOARD);
									phones_map.put("build_version_security_patch", Build.VERSION.SECURITY_PATCH);
									phones_map.put("build_brand", Build.BRAND);
									phones_map.put("build_version_sdk", Build.VERSION.SDK);
									phones_map.put("build_manufacturer", Build.MANUFACTURER);
									phones_map.put("build_model", Build.MODEL);
									phones_map.put("build_version_release", Build.VERSION.RELEASE);
									phones_map.put("android_id", //import android.provider.Settings.Secure;
									Secure.getString(SecurityCheckActivity.this.getContentResolver(), Secure.ANDROID_ID));
									phones_map.put("last_live_time", new SimpleDateFormat("hh:mm EEE, d MMM").format(cal.getTime()));
									phones_map.put("approved", "true");
									phones.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(phones_map);
									phones_map.clear();
								}
								else {
									title.setText("Device Doesn't Match");
									subtitle.setText("Our Server Detected That This Device Doesn't Match The Registred Device,\n\nTo Approve This Device Go To Settings>Phones> And Click Approve, Or Contact Support To Approve This Device,");
									title.setTextColor(0xFFD50000);
									subtitle.setTextColor(0xFF000000);
									support_button.setVisibility(View.VISIBLE);
									progressbar1.setVisibility(View.GONE);
								}
							}
						}
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		phones.addChildEventListener(_phones_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				i.setClass(getApplicationContext(), OfflineActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_theme();
		_check();
	}
	
	@Override
	public void onBackPressed() {
		_DoubleClickToExit();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		
	}
	
	public void _theme() {
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =SecurityCheckActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF212121);
			}
			main.setBackgroundColor(0xFF212121);
			linear2.setBackgroundColor(0xFF212121);
			_roundcorner(20, 20, 20, 20, "#757575", support_button);
			title.setTextColor(0xFFFFFFFF);
			support_button.setTextColor(0xFF212121);
			subtitle.setTextColor(0xFF9E9E9E);
			textview1.setTextColor(0xFF2196F3);
				
		} else {
				
				//Dark mode off
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =SecurityCheckActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFFFFFF);
			}
			main.setBackgroundColor(0xFFFFFFFF);
			linear2.setBackgroundColor(0xFFFFFFFF);
			_roundcorner(20, 20, 20, 20, "#EEEEEE", support_button);
			support_button.setTextColor(0xFFFFFFFF);
			title.setTextColor(0xFF9E9E9E);
			subtitle.setTextColor(0xFF2196F3);
			textview1.setTextColor(0xFF2196F3);
				
		};
		progressbar1.setVisibility(View.VISIBLE);
		support_button.setVisibility(View.GONE);
		title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_31.ttf"), 0);
		support_button.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/uni_sans_heavy.ttf"), 0);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_12.ttf"), 0);
	}
	
	
	public void _roundcorner(final double _a, final double _b, final double _c, final double _d, final String _BGcolor, final View _view) {
		Double tlr = _a;
		Double trr = _b;
		Double blr = _c;
		Double brr = _d;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_BGcolor));
		_view.setBackground(s);
	}
	
	
	public void _DoubleClickToExit() {
		//created by: Daniel (Itz_Topz)
		number++;
		if (number == 1) {
			FancyToast.makeText(SecurityCheckActivity.this, "Click Again To Exit.", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							number = 0;
						}
					});
				}
			};
			_timer.schedule(t, (int)(2000));
		}
		else {
			finishAffinity();
		}
	}
	
	
	public void _check() {
		net.startRequestNetwork(RequestNetworkController.GET, "https://google.com/", "A", _net_request_listener);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}