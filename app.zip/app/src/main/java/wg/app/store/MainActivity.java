package wg.app.store;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double number = 0;
	private String app_version = "";
	private HashMap<String, Object> server_map = new HashMap<>();
	private double batLevel = 0;
	private String language = "";
	private String sha1 = "";
	
	private LinearLayout main;
	
	private DatabaseReference Notify = _firebase.getReference("Notification");
	private ChildEventListener _Notify_child_listener;
	private Intent i = new Intent();
	private SharedPreferences settings;
	private TimerTask t;
	private DatabaseReference server = _firebase.getReference("server");
	private ChildEventListener _server_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		net = new RequestNetwork(this);
		
		_Notify_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Notify.addChildEventListener(_Notify_child_listener);
		
		_server_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("app_version")) {
					if (!app_version.equals(_childValue.get("app_version").toString())) {
						i.setClass(getApplicationContext(), UpdateAppActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
				if (_childValue.containsKey("maintenance")) {
					if (_childValue.get("maintenance").toString().equals("true")) {
						i.setClass(getApplicationContext(), MaintenanceActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("app_version")) {
					if (!app_version.equals(_childValue.get("app_version").toString())) {
						i.setClass(getApplicationContext(), UpdateAppActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
				if (_childValue.containsKey("maintenance")) {
					if (_childValue.get("maintenance").toString().equals("true")) {
						i.setClass(getApplicationContext(), MaintenanceActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("app_version")) {
					if (!app_version.equals(_childValue.get("app_version").toString())) {
						i.setClass(getApplicationContext(), UpdateAppActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
				if (_childValue.containsKey("maintenance")) {
					if (_childValue.get("maintenance").toString().equals("true")) {
						i.setClass(getApplicationContext(), MaintenanceActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		server.addChildEventListener(_server_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					if (batLevel < 16) {
						i.setClass(getApplicationContext(), LowBatteryActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
					else {
						i.setClass(getApplicationContext(), AuthActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
						finish();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				i.setClass(getApplicationContext(), OfflineActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		};
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.containsKey("banned")) {
							if (_childValue.get("banned").toString().equals("true")) {
								i.setClass(getApplicationContext(), BannedActivity.class);
								i.putExtra("reason", _childValue.get("reason").toString());
								i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i);
								finish();
							}
						}
						if (_childValue.containsKey("balance")) {
							if (Double.parseDouble(_childValue.get("balance").toString()) > 10000) {
								i.setClass(getApplicationContext(), BannedActivity.class);
								i.putExtra("reason", "Your Balance Is More Than $10,000 And Our Server Doesn't Allow So Much Money To Protect Our Servers From Hackers, To Deposit This Amount Of Money Into Your WG Wallet Please Contact Support So That We Can Allow Our Server To Continue The Transaction.");
								i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i);
								finish();
							}
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.containsKey("banned")) {
							if (_childValue.get("banned").toString().equals("true")) {
								i.setClass(getApplicationContext(), BannedActivity.class);
								i.putExtra("reason", _childValue.get("reason").toString());
								i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i);
								finish();
							}
						}
						if (_childValue.containsKey("balance")) {
							if (Double.parseDouble(_childValue.get("balance").toString()) > 10000) {
								i.setClass(getApplicationContext(), BannedActivity.class);
								i.putExtra("reason", "Your Balance Is More Than $10,000 And Our Server Doesn't Allow So Much Money To Protect Our Servers From Hackers, To Deposit This Amount Of Money Into Your WG Wallet Please Contact Support So That We Can Allow Our Server To Continue The Transaction.");
								i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i);
								finish();
							}
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.containsKey("banned")) {
							if (_childValue.get("banned").toString().equals("true")) {
								i.setClass(getApplicationContext(), BannedActivity.class);
								i.putExtra("reason", _childValue.get("reason").toString());
								i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i);
								finish();
							}
						}
						if (_childValue.containsKey("balance")) {
							if (Double.parseDouble(_childValue.get("balance").toString()) > 10000) {
								i.setClass(getApplicationContext(), BannedActivity.class);
								i.putExtra("reason", "Your Balance Is More Than $10,000 And Our Server Doesn't Allow So Much Money To Protect Our Servers From Hackers, To Deposit This Amount Of Money Into Your WG Wallet Please Contact Support So That We Can Allow Our Server To Continue The Transaction.");
								i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i);
								finish();
							}
						}
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_theme();
		//Get App Version
		String uri = "wg.app.store";
		android.content.pm.PackageManager pm = getPackageManager(); try { android.content.pm.PackageInfo pInfo = pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES); String version = pInfo.versionName; app_version = version; } catch (android.content.pm.PackageManager.NameNotFoundException e) { }
		//Start Background Service
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
				Intent ServiceIntent = new Intent(MainActivity.this, NotifyService.class);
				startService(ServiceIntent);
		}
		//Get Battery Percentage
		BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
		int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
		//Make Shortcuts
		android.content.pm.ShortcutManager shortcutManager = null;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
					shortcutManager = getSystemService(android.content.pm.ShortcutManager.class);
		}
		if (shortcutManager != null) {
					android.content.pm.ShortcutInfo apps_sc = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "Activity1")
					.setShortLabel("Apps")
					.setLongLabel("Apps")
					.setRank(1)
					.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, HomeActivity.class))
					.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.ic_apps_white))
					.build();
					android.content.pm.ShortcutInfo games_sc = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "Activity2")
					.setShortLabel("Games")
					.setLongLabel("Games")
					.setRank(2)
					.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, GamesActivity.class))
					.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.ic_gamepad_white))
					.build();
					android.content.pm.ShortcutInfo books_sc = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "Activity3")
					.setShortLabel("Books")
					.setLongLabel("Books")
					.setRank(3)
					.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, BooksActivity.class))
					.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.ic_local_library_white))
					.build();
					android.content.pm.ShortcutInfo movies_sc = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "Activity4")
					.setShortLabel("Movies")
					.setLongLabel("Movies")
					.setRank(4)
					.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, MoviesActivity.class))
					.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.ic_album_white))
					.build();
					android.content.pm.ShortcutInfo support_sc = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "Activity5")
					.setShortLabel("Support")
					.setLongLabel("Support")
					.setRank(5)
					.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, SupportActivity.class))
					.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.ic_public_white))
					.build();
				shortcutManager.setDynamicShortcuts(java.util.Arrays.asList(apps_sc, games_sc, books_sc, movies_sc, support_sc));
					
		}
		if (!FileUtil.isExistFile("/storage/emulated/0/WG App Store/")) {
			FileUtil.makeDir("/storage/emulated/0/WG App Store/");
			if (!FileUtil.isExistFile("/storage/emulated/0/WG App Store/Apps/")) {
				FileUtil.makeDir("/storage/emulated/0/WG App Store/Apps/");
				if (!FileUtil.isExistFile("/storage/emulated/0/WG App Store/Games/")) {
					FileUtil.makeDir("/storage/emulated/0/WG App Store/Games/");
					if (!FileUtil.isExistFile("/storage/emulated/0/WG App Store/Books/")) {
						FileUtil.makeDir("/storage/emulated/0/WG App Store/Books/");
						if (!FileUtil.isExistFile("/storage/emulated/0/WG App Store/Movies/")) {
							FileUtil.makeDir("/storage/emulated/0/WG App Store/Movies/");
							if (!FileUtil.isExistFile("/storage/emulated/0/WG App Store/Files/")) {
								FileUtil.makeDir("/storage/emulated/0/WG App Store/Files/");
							}
						}
					}
				}
			}
		}
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			//Loading View Dark Mode
			PlanetView2 bcv2 = new PlanetView2(this); main.addView(bcv2);
				
		} else {
				
				//Dark mode off
			//Loading Light Mode
			PlanetView bcv = new PlanetView(this); main.addView(bcv);
				
		};
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						_check();
					}
				});
			}
		};
		_timer.schedule(t, (int)(3000));
	}
	
	@Override
	public void onStart() {
		super.onStart();
		//MainActivity OnStart Logic
	}
	
	@Override
	public void onResume() {
		super.onResume();
		//MainActivity OnResume Logic
		_theme();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		//MainActivity OnPause Logic
	}
	
	@Override
	public void onBackPressed() {
		//MainActivity OnBackPressed Logic
		_DoubleClickToExit();
	}
	
	    public void onLowMemory() {
		        super.onLowMemory();
		        //MainActivity OnLowMemory Logic
		i.setClass(getApplicationContext(), LowMemoryActivity.class);
		i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(i);
		finish();
		        }
	public void _theme() {
		//MainActivity Theme Moreblock Logic
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =MainActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF212121);
			}
			main.setBackgroundColor(0xFF212121);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
				
		} else {
				
				//Dark mode off
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =MainActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFFFFFF);
			}
			main.setBackgroundColor(0xFFFFFFFF);
			getWindow().getDecorView()
			  .setSystemUiVisibility(
			    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
			  );
				
		};
	}
	
	
	public void _check() {
		net.startRequestNetwork(RequestNetworkController.GET, "https://google.com/", "A", _net_request_listener);
	}
	
	
	public void _extra() {
	} 
	
	public class PlanetView extends View { 
		
		private double angle=0;
		private Paint myPaint; 
		public PlanetView(Context context){ 
			super(context); 
			myPaint = new Paint(); 
			angle = 0; 
		} 
		
		@Override protected void onDraw(Canvas canvas) { 
			
			int viewWidth = this.getMeasuredWidth(); 
			int viewHeight = this.getMeasuredHeight(); angle = (angle + 0.001)%360; 
			
			float x = Math.round(260*Math.sin(Math.toDegrees(angle))); 
			float y = Math.round(110*Math.cos(Math.toDegrees(angle))); 
			float x2 = Math.round(120*Math.sin(90+Math.toDegrees(angle))); 
			float y2 = Math.round(290*Math.cos(90+Math.toDegrees(angle))); 
			float x3 = Math.round(130*Math.sin(180+Math.toDegrees(angle))); 
			float y3 = Math.round(230*Math.cos(180+Math.toDegrees(angle)));
			float x4 = Math.round(120*Math.sin(270+Math.toDegrees(angle))); 
			float y4 = Math.round(250*Math.cos(270+Math.toDegrees(angle)));
			
			
			 myPaint.setStyle(android.graphics.Paint.Style.FILL); 
			
			myPaint.setColor(Color.parseColor("#eceff1")); 
			canvas.drawCircle(viewWidth/2, viewHeight/2, (int)(x*1.5), myPaint);
			myPaint.setColor(Color.parseColor("#cfd8dc")); 
			canvas.drawCircle(viewWidth/2, viewHeight/2, (int)(x*1.5)-25, myPaint);
			
			myPaint.setColor(Color.parseColor("#275080")); canvas.drawCircle(viewWidth/2 + x, viewHeight/2 + y, 15, myPaint);
			
			myPaint.setColor(Color.parseColor("#DA3287")); canvas.drawCircle(viewWidth/2 + x2, viewHeight/2 + y2, 20, myPaint);
			
			myPaint.setColor(Color.parseColor("#008001")); canvas.drawCircle(viewWidth/2 + x3, viewHeight/2 + y3, 30, myPaint);
			
			myPaint.setColor(Color.parseColor("#8B0000")); canvas.drawCircle(viewWidth/2 + x4, viewHeight/2 + y4, 10, myPaint);
			
			
			
			android.graphics.drawable.Drawable d = getResources().getDrawable(R.drawable.logo, null);
			d.setBounds((int)((viewWidth/2)-80-x/11), (int)((viewHeight/2)-80-x/11), (int)((viewWidth/2)+80+x/11), (int)((viewHeight/2)+80+x/11)); 
			d.draw(canvas);
			
			
			invalidate(); 
			
		}
	} 
	
	public class PlanetView2 extends View { 
		
		private double angle=0;
		private Paint myPaint; 
		public PlanetView2(Context context){ 
			super(context); 
			myPaint = new Paint(); 
			angle = 0; 
		} 
		
		@Override protected void onDraw(Canvas canvas) { 
			
			int viewWidth = this.getMeasuredWidth(); 
			int viewHeight = this.getMeasuredHeight(); angle = (angle + 0.001)%360; 
			
			float x = Math.round(260*Math.sin(Math.toDegrees(angle))); 
			float y = Math.round(110*Math.cos(Math.toDegrees(angle))); 
			float x2 = Math.round(120*Math.sin(90+Math.toDegrees(angle))); 
			float y2 = Math.round(290*Math.cos(90+Math.toDegrees(angle))); 
			float x3 = Math.round(130*Math.sin(180+Math.toDegrees(angle))); 
			float y3 = Math.round(230*Math.cos(180+Math.toDegrees(angle)));
			float x4 = Math.round(120*Math.sin(270+Math.toDegrees(angle))); 
			float y4 = Math.round(250*Math.cos(270+Math.toDegrees(angle)));
			
			
			 myPaint.setStyle(android.graphics.Paint.Style.FILL); 
			
			myPaint.setColor(Color.parseColor("#9e9e9e")); 
			canvas.drawCircle(viewWidth/2, viewHeight/2, (int)(x*1.5), myPaint);
			myPaint.setColor(Color.parseColor("#757575")); 
			canvas.drawCircle(viewWidth/2, viewHeight/2, (int)(x*1.5)-25, myPaint);
			
			myPaint.setColor(Color.parseColor("#275080")); canvas.drawCircle(viewWidth/2 + x, viewHeight/2 + y, 15, myPaint);
			
			myPaint.setColor(Color.parseColor("#DA3287")); canvas.drawCircle(viewWidth/2 + x2, viewHeight/2 + y2, 20, myPaint);
			
			myPaint.setColor(Color.parseColor("#008001")); canvas.drawCircle(viewWidth/2 + x3, viewHeight/2 + y3, 30, myPaint);
			
			myPaint.setColor(Color.parseColor("#8B0000")); canvas.drawCircle(viewWidth/2 + x4, viewHeight/2 + y4, 10, myPaint);
			
			
			
			android.graphics.drawable.Drawable d = getResources().getDrawable(R.drawable.logo, null);
			d.setBounds((int)((viewWidth/2)-80-x/11), (int)((viewHeight/2)-80-x/11), (int)((viewWidth/2)+80+x/11), (int)((viewHeight/2)+80+x/11)); 
			d.draw(canvas);
			
			
			invalidate(); 
			
		}
	}
	
	
	public void _DoubleClickToExit() {
		//created by: Daniel (Itz_Topz)
		number++;
		if (number == 1) {
			FancyToast.makeText(MainActivity.this, "Click Again To Exit.", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							number = 0;
						}
					});
				}
			};
			_timer.schedule(t, (int)(2000));
		}
		else {
			finishAffinity();
		}
	}
	
	
	public void _save(final String _file, final String _path, final String _file2) {
		FileUtil.writeFile("Thanks", "By Arab Ware Channel");
		try{
			int count;
			java.io.InputStream input= this.getAssets().open(_file);
			java.io.OutputStream output = new  java.io.FileOutputStream(_path+_file2);
			byte data[] = new byte[1024];
			while ((count = input.read(data))>0) {
				output.write(data, 0, count);
			}
			output.flush();
			output.close();
			input.close();
			
			}catch(Exception e){
					
			}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}