package wg.app.store;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.github.florent37.viewtooltip.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jsibbold.zoomage.*;
import com.mannan.translateapi.*;
import com.shashank.sony.fancytoastlib.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class SupportActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String user_pic = "";
	private double generated_id = 0;
	private HashMap<String, Object> support_map = new HashMap<>();
	private HashMap<String, Object> admin_notify_map = new HashMap<>();
	private String sup_category = "";
	
	private LinearLayout linear2;
	private LinearLayout main;
	private ImageView imageview1;
	private LinearLayout linear4;
	private ImageView imageview2;
	private TextView title;
	private LinearLayout profile_back;
	private LinearLayout category_back;
	private LinearLayout message_back;
	private Button send_button;
	private CircleImageView pic;
	private LinearLayout linear3;
	private TextView name;
	private TextView email;
	private TextView category_title;
	private LinearLayout linear1;
	private EditText category;
	private TextView select;
	private TextView message_title;
	private EditText message;
	private TextView chapter_counter;
	
	private AlertDialog.Builder dialog;
	private DatabaseReference support = _firebase.getReference("support");
	private ChildEventListener _support_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private Calendar calendar = Calendar.getInstance();
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private Intent i = new Intent();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private DatabaseReference admin_notify = _firebase.getReference("admin_notify");
	private ChildEventListener _admin_notify_child_listener;
	private SharedPreferences settings;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.support);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		main = findViewById(R.id.main);
		imageview1 = findViewById(R.id.imageview1);
		linear4 = findViewById(R.id.linear4);
		imageview2 = findViewById(R.id.imageview2);
		title = findViewById(R.id.title);
		profile_back = findViewById(R.id.profile_back);
		category_back = findViewById(R.id.category_back);
		message_back = findViewById(R.id.message_back);
		send_button = findViewById(R.id.send_button);
		pic = findViewById(R.id.pic);
		linear3 = findViewById(R.id.linear3);
		name = findViewById(R.id.name);
		email = findViewById(R.id.email);
		category_title = findViewById(R.id.category_title);
		linear1 = findViewById(R.id.linear1);
		category = findViewById(R.id.category);
		select = findViewById(R.id.select);
		message_title = findViewById(R.id.message_title);
		message = findViewById(R.id.message);
		chapter_counter = findViewById(R.id.chapter_counter);
		dialog = new AlertDialog.Builder(this);
		auth = FirebaseAuth.getInstance();
		net = new RequestNetwork(this);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://wgstudio.xyz"));
				startActivity(i);
			}
		});
		
		send_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (category.equals("")) {
					FancyToast.makeText(SupportActivity.this, "Select A Category!", FancyToast.LENGTH_LONG, FancyToast.WARNING, false).show();
				}
				else {
					if (message.getText().toString().equals("")) {
						((EditText)message).setError("Enter Your Message!");
					}
					else {
						if (message.getText().toString().length() < 80) {
							FancyToast.makeText(SupportActivity.this, "Message Minimum Length Is 80 Chapters...", FancyToast.LENGTH_LONG, FancyToast.WARNING, false).show();
						}
						else {
							calendar = Calendar.getInstance();
							support_map = new HashMap<>();
							if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
								support_map.put("pic", user_pic);
								support_map.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
							}
							support_map.put("name", name.getText().toString());
							support_map.put("category", sup_category);
							support_map.put("message", message.getText().toString());
							support_map.put("time", new SimpleDateFormat("hh:mm EEE, d MMM").format(calendar.getTime()));
							support_map.put("id", String.valueOf((long)(generated_id)));
							if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
								support_map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
							}
							support.child(String.valueOf((long)(generated_id))).updateChildren(support_map);
							support_map.clear();
							admin_notify_map = new HashMap<>();
							admin_notify_map.put("title", "New Support Ticket.");
							admin_notify_map.put("message", "User: ".concat(name.getText().toString().concat(" Sent A New Support Ticket.")));
							admin_notify_map.put("readed", "false");
							if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
								admin_notify_map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
							}
							admin_notify.push().updateChildren(admin_notify_map);
							admin_notify_map.clear();
							i.setClass(getApplicationContext(), SupportSuccessfullActivity.class);
							i.putExtra("id", String.valueOf((long)(generated_id)));
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
						}
					}
				}
			}
		});
		
		category.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (!_charSeq.equals("")) {
					sup_category = _charSeq;
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		select.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog dialog = new com.google.android.material.bottomsheet.BottomSheetDialog(SupportActivity.this);
				
				View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.support_category_view,null );
				dialog.setContentView(bottomSheetView);
				
				dialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				LinearLayout main = (LinearLayout) bottomSheetView.findViewById(R.id.main);
				LinearLayout btn1 = (LinearLayout) bottomSheetView.findViewById(R.id.btn1);
				LinearLayout btn2 = (LinearLayout) bottomSheetView.findViewById(R.id.btn2);
				LinearLayout btn3 = (LinearLayout) bottomSheetView.findViewById(R.id.btn3);
				LinearLayout btn4 = (LinearLayout) bottomSheetView.findViewById(R.id.btn4);
				LinearLayout btn5 = (LinearLayout) bottomSheetView.findViewById(R.id.btn5);
				LinearLayout btn6 = (LinearLayout) bottomSheetView.findViewById(R.id.btn6);
				LinearLayout btn7 = (LinearLayout) bottomSheetView.findViewById(R.id.btn7);
				LinearLayout btn8 = (LinearLayout) bottomSheetView.findViewById(R.id.btn8);
				LinearLayout btn9 = (LinearLayout) bottomSheetView.findViewById(R.id.btn9);
				dialog.setCancelable(false);
				TextView title = (TextView) bottomSheetView.findViewById(R.id.title);
				TextView text1 = (TextView) bottomSheetView.findViewById(R.id.text1);
				TextView text2 = (TextView) bottomSheetView.findViewById(R.id.text2);
				TextView text3 = (TextView) bottomSheetView.findViewById(R.id.text3);
				TextView text4 = (TextView) bottomSheetView.findViewById(R.id.text4);
				TextView text5 = (TextView) bottomSheetView.findViewById(R.id.text5);
				TextView text6 = (TextView) bottomSheetView.findViewById(R.id.text6);
				TextView text7 = (TextView) bottomSheetView.findViewById(R.id.text7);
				TextView text8 = (TextView) bottomSheetView.findViewById(R.id.text8);
				TextView text9 = (TextView) bottomSheetView.findViewById(R.id.text9);
				getWindow().getDecorView()
				  .setSystemUiVisibility(
				    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
				  );
				int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
				if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
						
						//Dark Mode On
					int[] colorsCRNNC = { Color.parseColor("#212121"), Color.parseColor("#212121") }; android.graphics.drawable.GradientDrawable CRNNC = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNNC);
					CRNNC.setCornerRadii(new float[]{(int)25,(int)25,(int)25,(int)25,(int)0,(int)0,(int)0,(int)0});
					CRNNC.setStroke((int) 0, Color.parseColor("#000000"));
					main.setElevation((float) 5);
					main.setBackground(CRNNC);
					
					//Paste this code in (add source directly block) asd block
					//Milz
					btn1.setBackgroundColor(0xFF757575);
					btn2.setBackgroundColor(0xFF757575);
					btn3.setBackgroundColor(0xFF757575);
					btn4.setBackgroundColor(0xFF757575);
					btn5.setBackgroundColor(0xFF757575);
					btn6.setBackgroundColor(0xFF757575);
					btn7.setBackgroundColor(0xFF757575);
					btn8.setBackgroundColor(0xFF757575);
					btn9.setBackgroundColor(0xFF757575);
					title.setTextColor(0xFFFFFFFF);
					text1.setTextColor(0xFFFFFFFF);
					text2.setTextColor(0xFFFFFFFF);
					text3.setTextColor(0xFFFFFFFF);
					text4.setTextColor(0xFFFFFFFF);
					text5.setTextColor(0xFFFFFFFF);
					text6.setTextColor(0xFFFFFFFF);
					text7.setTextColor(0xFFFFFFFF);
					text8.setTextColor(0xFFFFFFFF);
					text9.setTextColor(0xFFFFFFFF);
						
				} else {
						
						//Dark mode off
					int[] colorsCRNGJ = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNGJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNGJ);
					CRNGJ.setCornerRadii(new float[]{(int)25,(int)25,(int)25,(int)25,(int)0,(int)0,(int)0,(int)0});
					CRNGJ.setStroke((int) 0, Color.parseColor("#000000"));
					main.setElevation((float) 5);
					main.setBackground(CRNGJ);
					
					//Paste this code in (add source directly block) asd block
					//Milz
					btn1.setBackgroundColor(0xFFEEEEEE);
					btn2.setBackgroundColor(0xFFEEEEEE);
					btn3.setBackgroundColor(0xFFEEEEEE);
					btn4.setBackgroundColor(0xFFEEEEEE);
					btn5.setBackgroundColor(0xFFEEEEEE);
					btn6.setBackgroundColor(0xFFEEEEEE);
					btn7.setBackgroundColor(0xFFEEEEEE);
					btn8.setBackgroundColor(0xFFEEEEEE);
					btn9.setBackgroundColor(0xFFEEEEEE);
					title.setTextColor(0xFF000000);
					text1.setTextColor(0xFF000000);
					text2.setTextColor(0xFF000000);
					text3.setTextColor(0xFF000000);
					text4.setTextColor(0xFF000000);
					text5.setTextColor(0xFF000000);
					text6.setTextColor(0xFF000000);
					text7.setTextColor(0xFF000000);
					text8.setTextColor(0xFF000000);
					text9.setTextColor(0xFF000000);
						
				};
				btn1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Banned Account");
						sup_category = "Banned Account";
						dialog.dismiss();
					}
				});
				btn2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("App Crashes");
						sup_category = "App Crashes";
						dialog.dismiss();
					}
				});
				btn3.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Network Problems");
						sup_category = "Network Problems";
						dialog.dismiss();
					}
				});
				btn4.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Account Problems");
						sup_category = "Account Problems";
						dialog.dismiss();
					}
				});
				btn5.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Security Problems");
						sup_category = "Security Problems";
						dialog.dismiss();
					}
				});
				btn6.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Server Problems");
						sup_category = "Server Problems";
						dialog.dismiss();
					}
				});
				btn7.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Download Problems");
						sup_category = "Download Problems";
						dialog.dismiss();
					}
				});
				btn8.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						select.setText("Upload Problems");
						sup_category = "Upload Problems";
						dialog.dismiss();
					}
				});
				btn9.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						category.setVisibility(View.VISIBLE);
						select.setVisibility(View.GONE);
						dialog.dismiss();
					}
				});
				dialog.show();
			}
		});
		
		message.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (!_charSeq.equals("")) {
					chapter_counter.setText("Total ".concat(String.valueOf((long)(_charSeq.length())).concat(" Chapters")));
					if (_charSeq.length() > 79) {
						chapter_counter.setTextColor(0xFF4CAF50);
					}
					else {
						if (_charSeq.length() > 30) {
							chapter_counter.setTextColor(0xFF2196F3);
						}
						else {
							chapter_counter.setTextColor(0xFFD50000);
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_support_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		support.addChildEventListener(_support_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.containsKey("pic")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(pic);
							user_pic = _childValue.get("pic").toString();
						}
						if (_childValue.containsKey("name")) {
							name.setText(_childValue.get("name").toString());
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.containsKey("pic")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(pic);
							user_pic = _childValue.get("pic").toString();
						}
						if (_childValue.containsKey("name")) {
							name.setText(_childValue.get("name").toString());
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.containsKey("pic")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("pic").toString())).into(pic);
							user_pic = _childValue.get("pic").toString();
						}
						if (_childValue.containsKey("name")) {
							name.setText(_childValue.get("name").toString());
						}
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				i.setClass(getApplicationContext(), OfflineActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		};
		
		_admin_notify_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		admin_notify.addChildEventListener(_admin_notify_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			email.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
		}
		else {
			profile_back.setVisibility(View.GONE);
		}
		generated_id = SketchwareUtil.getRandom((int)(00000000), (int)(99999999));
		_theme();
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		
	}
	public void _theme() {
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		getWindow().getDecorView()
		  .setSystemUiVisibility(
		    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		  );
		int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
		if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				//Dark Mode On
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =SupportActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF00BCD4);
			}
			main.setBackgroundColor(0xFF212121);
			_roundcorner(20, 20, 20, 20, "#757575", category_back);
			_roundcorner(20, 20, 20, 20, "#757575", message_back);
			_roundcorner(20, 20, 20, 20, "#757575", profile_back);
			_roundcorner(20, 20, 20, 20, "#FFFFFF", send_button);
			message.setBackgroundColor(0xFF757575);
			message.setTextColor(0xFFFFFFFF);
			message_title.setTextColor(0xFFFFFFFF);
			category_title.setTextColor(0xFFFFFFFF);
			select.setTextColor(0xFFFFFFFF);
			title.setTextColor(0xFFFFFFFF);
			name.setTextColor(0xFFFFFFFF);
			email.setTextColor(0xFFFFFFFF);
			send_button.setTextColor(0xFF212121);
				
		} else {
				
				//Dark mode off
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w =SupportActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF00BCD4);
			}
			main.setBackgroundColor(0xFFFFFFFF);
			_roundcorner(20, 20, 20, 20, "#EEEEEE", category_back);
			_roundcorner(20, 20, 20, 20, "#EEEEEE", message_back);
			_roundcorner(20, 20, 20, 20, "#EEEEEE", profile_back);
			_roundcorner(20, 20, 20, 20, "#000000", send_button);
			message.setBackgroundColor(0xFFEEEEEE);
			message.setTextColor(0xFF000000);
			message_title.setTextColor(0xFF000000);
			category_title.setTextColor(0xFF000000);
			select.setTextColor(0xFF000000);
			title.setTextColor(0xFF000000);
			name.setTextColor(0xFF000000);
			email.setTextColor(0xFF000000);
			send_button.setTextColor(0xFFFFFFFF);
				
		};
		category.setVisibility(View.GONE);
		select.setVisibility(View.VISIBLE);
		title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_31.ttf"), 0);
		send_button.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/uni_sans_heavy.ttf"), 0);
		category_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/Roboto-BoldCondensed.ttf"), 0);
		select.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/Roboto-BoldCondensed.ttf"), 0);
		message_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_12.ttf"), 0);
		chapter_counter.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_12.ttf"), 0);
	}
	
	
	public void _roundcorner(final double _a, final double _b, final double _c, final double _d, final String _BGcolor, final View _view) {
		Double tlr = _a;
		Double trr = _b;
		Double blr = _c;
		Double brr = _d;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_BGcolor));
		_view.setBackground(s);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}